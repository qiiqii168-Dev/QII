# KHMER GAME PORT — iOS IPA Build

This project has an EAS Build profile in `artifacts/khmer-game-port/eas.json`.

## Important
- A signed iOS IPA cannot be produced in this Linux workspace. iOS compilation/signing must run on Apple's macOS build machines (for example, Expo EAS Build) and requires the owner's Expo account plus Apple signing credentials where required.
- The app's bundle identifier is `com.qiiqii.khmergameport`.
- Creating an IPA does not add a Windows/PC GTA V runtime. A ZIP download is only file transfer; the app still needs a compatible local game runtime. No streaming functionality is configured by this guide.

## Build using Expo EAS
1. Install Node.js LTS on a Mac or PC and install the project dependencies with pnpm from the repository root.
2. Open a terminal in `artifacts/khmer-game-port`.
3. Run `npx eas-cli login` and sign in to your own Expo account.
4. Run `npx eas-cli build:configure` if EAS asks to link/create an Expo project. Review the generated `extra.eas.projectId` before continuing.
5. Run `npx eas-cli build --platform ios --profile preview` for an installable internal-testing IPA, or `npx eas-cli build --platform ios --profile production` for a production build.
6. Follow EAS prompts for iOS credentials. Use your own Apple Developer account and do not share passwords or private keys in chat.
7. When the cloud build completes, download the IPA from the EAS build page and install it using the distribution method EAS provides.

## Before release
Run the app on a real iPhone and test document permissions, large downloads, archive extraction, and controller interaction. Large-file support is limited by available device storage, server behavior, iOS background execution, and the implementation of the individual feature; it is not unlimited in practice.
