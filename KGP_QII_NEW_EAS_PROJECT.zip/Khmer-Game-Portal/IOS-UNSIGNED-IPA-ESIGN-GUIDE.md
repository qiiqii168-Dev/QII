# KGP QII — unsigned IPA build for ESign

This workflow is an **additional build path**. It does not replace or delete the original project files, `eas.json`, `app.json`, or the root `pnpm-lock.yaml`.

## Build the IPA

1. Upload/extract this project into your GitHub repository, preserving the `Khmer-Game-Portal` contents as the repository root.
2. Open the repository on GitHub and go to **Actions**.
3. Select **Build unsigned iOS IPA for ESign**.
4. Press **Run workflow** and wait for the macOS build to finish.
5. Open the completed run and download the `KGP-QII-unsigned-IPA` artifact. It contains `KGP_QII_unsigned_for_ESign.ipa`.
6. Import that IPA into ESign and sign it using a valid signing certificate and provisioning profile that match the app's bundle identifier.

## Important limitations

- This workflow creates an **unsigned** device IPA package; it does not sign the app and does not itself install it on an iPhone.
- ESign still needs a usable signing certificate and provisioning profile. This workflow does not create Apple signing credentials or bypass Apple's signing requirements.
- The workflow runs on GitHub's macOS/Xcode runner. It has not been executed from this chat, so an IPA has **not** yet been produced or verified.
- The app's current bundle identifier is `com.qiiqii.khmergameport` (from the existing `app.json`). Keep the signing profile compatible with that identifier.
- The original EAS configuration is preserved. The new workflow uses the monorepo's existing root `pnpm-lock.yaml`, avoiding the earlier missing-lockfile issue caused by building from the nested Expo app directory.

## Original-file preservation

Only these two new files are added:

- `.github/workflows/ios-unsigned-ipa.yml`
- `IOS-UNSIGNED-IPA-ESIGN-GUIDE.md`

No existing file is intentionally edited or removed.
