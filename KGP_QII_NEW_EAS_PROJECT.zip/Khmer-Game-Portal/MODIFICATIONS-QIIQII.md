# KHMER GAME PORT — changes applied to the original project

This delivery starts from the supplied `KGP-QIIQII.zip` project and preserves its original folder structure and existing source files. Changes are additive or narrowly targeted.

## Applied
- Removed the app-defined 500 MB download cutoff from both initial downloads and resumed downloads. Existing HTTPS validation, progress reporting, pause/resume/cancel flow, and download queue are retained. Actual downloads remain constrained by free device storage, iOS behavior, and server support; downloads are foreground-only in this implementation.
- Removed the app-defined 512 MB file-import cutoff. The Files picker now imports arbitrary selected file types into the app's private storage (subject to iOS storage and file-provider limits).
- Added the 69 original PNG control icons supplied in `Control game.zip` to `artifacts/khmer-game-port/assets/control-icons/` and added an icon gallery to the existing Controls tool. Existing control presets and preview remain.
- Added a Supporter card in Settings for Qii Qii with a Telegram deep link to https://t.me/qiiqii168.
- No PC, cloud, or game streaming code was added.

## Not represented as completed
- ZIP extraction still uses the existing JavaScript `fflate` in-memory extraction path and retains its safety limits: 25 MB compressed, 64 MB expanded, and 300 entries. It is not a 20 GB streaming extractor.
- The app's controller is still a layout/preset preview. iOS apps cannot draw touch controls over another app, and this project does not contain a GTA V-compatible local runtime. Downloading a GTA V archive does not make it playable on iPhone by itself.
- No signed IPA was produced. A macOS/Xcode build and signing identity are required to build and sign an iOS IPA.

## Validation
- Source edits and archive integrity checked in this environment.
- A full Expo/TypeScript build and iPhone runtime test were not run because dependencies/Xcode and a physical iPhone runtime are not available here.
