/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#F3EFE8',
    tint: '#E5A52E',

    // Core surfaces
    background: '#0B0B0A',
    foreground: '#F3EFE8',

    // Cards / elevated surfaces
    card: '#161513',
    cardForeground: '#F3EFE8',

    // Primary action color (buttons, links, active states)
    primary: '#E5A52E',
    primaryForeground: '#11100E',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#211F1B',
    secondaryForeground: '#EDE6D8',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#201E1A',
    mutedForeground: '#A39C90',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#E5A52E',
    accentForeground: '#11100E',

    // Destructive actions (delete, error states)
    destructive: '#EF665A',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#312E28',
    input: '#312E28',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
