import { requireOptionalNativeModule } from 'expo-modules-core';

export type GTAEngineStatus = {
  nativeBridgeAvailable: boolean;
  upstreamSourceBundled: boolean;
  engineBuildInputsPresent: boolean;
  engineLinked: boolean;
  metalRendererLinked: boolean;
  wasmArm64RuntimeLinked: boolean;
  gameFilesReady: boolean;
  storyModeAvailable: boolean;
  sandboxAvailable: boolean;
  message: string;
};

type GTAEngineNativeModule = {
  getStatus: () => GTAEngineStatus;
  launch: (mode: 'story' | 'sandbox') => Promise<{ started: boolean; reason?: string }>;
};

const nativeModule = requireOptionalNativeModule<GTAEngineNativeModule>('GTAEngine');

export async function getGTAEngineStatus(): Promise<GTAEngineStatus> {
  if (!nativeModule) {
    return {
      nativeBridgeAvailable: false, upstreamSourceBundled: true, engineBuildInputsPresent: false,
      engineLinked: false, metalRendererLinked: false,
      wasmArm64RuntimeLinked: false, gameFilesReady: false, storyModeAvailable: false,
      sandboxAvailable: false, message: 'Native GTA bridge is not installed in this app build.'
    };
  }
  return nativeModule.getStatus();
}

export async function launchGTA(mode: 'story' | 'sandbox') {
  if (!nativeModule) return { started: false, reason: 'Native GTA bridge is not installed in this app build.' };
  return nativeModule.launch(mode);
}
