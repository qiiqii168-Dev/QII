Pod::Spec.new do |s|
  s.name           = 'GTAEngine'
  s.version        = '0.1.0'
  s.summary        = 'KGP QII native GTA engine integration bridge'
  s.description    = 'Native bridge contract for a separately integrated GTA V iOS engine.'
  s.license        = { :type => 'MIT' }
  s.author         = 'KGP QII'
  s.homepage       = 'https://github.com/kevinerikjs/gta5-ios-port'
  s.source         = { :path => '.' }
  s.platform       = :ios, '16.0'
  s.swift_version  = '5.9'
  s.source_files   = 'ios/**/*.{h,m,mm,swift}'
  s.dependency 'ExpoModulesCore'
end
