import ExpoModulesCore
import Foundation

/// KGP QII's native integration boundary for the upstream GTA V iOS port.
/// Upstream source is bundled under vendor/gta5-ios-port-upstream, but it is a
/// standalone application target. The generated WASM engine and WABT toolchain
/// are absent from the supplied source archive, so this bridge must not claim
/// that gameplay is ready until a real engine adapter is built and linked.
public final class GTAEngineModule: Module {
  public func definition() -> ModuleDefinition {
    Name("GTAEngine")

    Function("getStatus") { () -> [String: Any] in
      return [
        "nativeBridgeAvailable": true,
        "upstreamSourceBundled": true,
        "engineBuildInputsPresent": false,
        "engineLinked": false,
        "metalRendererLinked": false,
        "wasmArm64RuntimeLinked": false,
        "gameFilesReady": false,
        "storyModeAvailable": false,
        "sandboxAvailable": false,
        "message": "GTA V upstream source is bundled. The upstream project is a standalone iOS app; generated WASM engine files and WABT toolchain are missing, so KGP gameplay is not linked yet."
      ]
    }

    AsyncFunction("launch") { (mode: String) -> [String: Any] in
      let normalized = mode.lowercased()
      guard normalized == "story" || normalized == "sandbox" else {
        return ["started": false, "reason": "Unsupported game mode."]
      }
      return [
        "started": false,
        "reason": "GTA V runtime is not linked. No game process was started."
      ]
    }
  }
}
