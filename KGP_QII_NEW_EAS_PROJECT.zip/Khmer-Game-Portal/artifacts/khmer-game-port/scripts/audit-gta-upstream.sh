#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
UP="$ROOT/vendor/gta5-ios-port-upstream/app"
[ -f "$UP/project.yml" ] || { echo 'ERROR: upstream project.yml missing'; exit 1; }
[ -f "$UP/Scripts/prepare.py" ] || { echo 'ERROR: prepare.py missing'; exit 1; }
missing=0
for path in "$UP/Generated" "$UP/GeneratedResources" "$UP/Tools/wabt-1.0.42"; do
  if [ -e "$path" ]; then echo "PRESENT: ${path#"$ROOT/"}"; else echo "MISSING: ${path#"$ROOT/"}"; missing=1; fi
done
printf '\nUpstream native source: PRESENT\nKGP Expo bridge: PRESENT\n'
if [ "$missing" -eq 1 ]; then
  echo 'Engine build is not ready: required generated/toolchain inputs are absent.'
  exit 2
fi
echo 'Required source build inputs are present; Xcode build still requires macOS.'
