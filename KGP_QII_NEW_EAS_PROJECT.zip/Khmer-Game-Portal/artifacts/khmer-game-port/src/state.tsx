import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  createDownloadResumable,
  deleteAsync,
  documentDirectory,
  FileSystemSessionType,
  getInfoAsync,
  makeDirectoryAsync,
  type DownloadResumable,
} from 'expo-file-system/legacy';
import {
  initialAppData,
  makeId,
  type AppData,
  type DownloadRecord,
} from './models';
import {
  isSupportedGameFile,
  newVaultFile,
  validateHttpsDownloadUrl,
} from './file-service';

const STORAGE_KEY = 'khmer-game-port:state:v1';

type DownloadProbe = {
  totalBytes: number;
  rangeSupport: 'yes' | 'no' | 'unknown';
  etag?: string;
  lastModified?: string;
  contentType?: string;
  fileName?: string;
};

/**
 * HEAD is metadata-only: it avoids downloading even a byte of a large file.
 * Some hosts reject HEAD or hide headers; that is reported as unknown and
 * does not prevent a normal download attempt.
 */
async function inspectDownloadUrl(url: string): Promise<DownloadProbe> {
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : undefined;
  const timeout = setTimeout(() => controller?.abort(), 9000);
  try {
    const response = await fetch(url, {
      method: 'HEAD',
      redirect: 'follow',
      signal: controller?.signal,
    });
    const lengthHeader = response.headers.get('content-length');
    const length = lengthHeader ? Number(lengthHeader) : 0;
    const acceptRanges = response.headers.get('accept-ranges')?.toLowerCase();
    const disposition = response.headers.get('content-disposition') ?? '';
    const utf8Name = disposition.match(/filename\*=UTF-8''([^;]+)/i)?.[1];
    const plainName = disposition.match(/filename=[\"']?([^\"';]+)[\"']?/i)?.[1];
    let fileName: string | undefined;
    try { fileName = decodeURIComponent(utf8Name ?? plainName ?? '').trim() || undefined; } catch { fileName = plainName?.trim() || undefined; }
    return {
      totalBytes: Number.isFinite(length) && length > 0 ? length : 0,
      rangeSupport: acceptRanges?.includes('bytes') ? 'yes' : acceptRanges ? 'no' : 'unknown',
      etag: response.headers.get('etag') ?? undefined,
      lastModified: response.headers.get('last-modified') ?? undefined,
      contentType: response.headers.get('content-type') ?? undefined,
      fileName,
    };
  } catch {
    return { totalBytes: 0, rangeSupport: 'unknown' };
  } finally {
    clearTimeout(timeout);
  }
}

interface AppContextValue {
  data: AppData;
  ready: boolean;
  persistenceError: string | null;
  updateData: (update: (current: AppData) => AppData) => void;
  logActivity: (label: string, kind: AppData['activity'][number]['kind']) => void;
  startDownload: (url: string) => Promise<string>;
  pauseDownload: (id: string) => Promise<void>;
  resumeDownload: (id: string) => Promise<void>;
  cancelDownload: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => initialAppData());
  const [ready, setReady] = useState(false);
  const [persistenceError, setPersistenceError] = useState<string | null>(null);
  const tasks = useRef<Record<string, DownloadResumable>>({});
  const progressSamples = useRef<Record<string, { bytes: number; at: number }>>({});

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((saved) => {
        if (!mounted) return;
        if (saved) {
          const parsed = JSON.parse(saved) as AppData;
          if (parsed.version === 1 && parsed.preferences && Array.isArray(parsed.games)) {
            setData({
              ...initialAppData(),
              ...parsed,
              downloads: (parsed.downloads ?? []).map((download) =>
                download.status === 'downloading'
                  ? download.resumeData
                    ? { ...download, status: 'paused', error: undefined }
                    : { ...download, status: 'failed', error: 'The app was closed before a resume checkpoint was saved. Restart this download from the beginning.' }
                  : download,
              ),
            });
          } else {
            setPersistenceError('Saved data could not be read. A fresh local profile is in use.');
          }
        }
      })
      .catch(() => {
        if (mounted) {
          setPersistenceError('Saved data could not be opened. Restart the app or reset its local data.');
        }
      })
      .finally(() => {
        if (mounted) setReady(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() => {
      setPersistenceError('Changes could not be saved to this device.');
    });
  }, [data, ready]);

  const updateData = useCallback((update: (current: AppData) => AppData) => {
    setData(update);
  }, []);

  const logActivity = useCallback(
    (label: string, kind: AppData['activity'][number]['kind']) => {
      updateData((current) => ({
        ...current,
        activity: [
          ...current.activity,
          { id: makeId('activity'), label, kind, createdAt: Date.now() },
        ].slice(-250),
      }));
    },
    [updateData],
  );

  const updateDownload = useCallback(
    (id: string, changes: Partial<DownloadRecord>) => {
      updateData((current) => ({
        ...current,
        downloads: current.downloads.map((entry) =>
          entry.id === id ? { ...entry, ...changes } : entry,
        ),
      }));
    },
    [updateData],
  );

  const startDownload = useCallback(
    async (input: string) => {
      const url = validateHttpsDownloadUrl(input);
      if (!documentDirectory) {
        throw new Error('Downloads require the app’s local file storage on a device.');
      }
      const dir = `${documentDirectory}khmer-game-port/downloads/`;
      if (!(await getInfoAsync(dir)).exists) {
        await makeDirectoryAsync(dir, { intermediates: true });
      }
      const parsed = new URL(url);
      const probe = await inspectDownloadUrl(url);
      const requestedName = (probe.fileName || decodeURIComponent(parsed.pathname.split('/').pop() || 'download.bin'))
        .replace(/[\\/:*?"<>|]/g, '_')
        .slice(-120);
      const fileName = requestedName || 'download.bin';
      const id = makeId('download');
      const fileUri = `${dir}${id}-${fileName}`;
      const record: DownloadRecord = {
        id,
        url,
        fileName,
        fileUri,
        status: 'downloading',
        transferredBytes: 0,
        totalBytes: probe.totalBytes,
        createdAt: Date.now(),
        rangeSupport: probe.rangeSupport,
        serverETag: probe.etag,
        serverLastModified: probe.lastModified,
        contentType: probe.contentType,
      };
      updateData((current) => ({
        ...current,
        downloads: [record, ...current.downloads],
        activity: [
          ...current.activity,
          { id: makeId('activity'), label: `Download started: ${fileName}`, kind: 'download' as const, createdAt: Date.now() },
        ].slice(-250),
      }));

      let task: DownloadResumable;
      task = createDownloadResumable(
        url,
        fileUri,
        { sessionType: FileSystemSessionType.FOREGROUND },
        (progress) => {
          const now = Date.now();
          const previous = progressSamples.current[id];
          const elapsed = previous ? Math.max(0.25, (now - previous.at) / 1000) : 0;
          const speed = previous && progress.totalBytesWritten >= previous.bytes
            ? (progress.totalBytesWritten - previous.bytes) / elapsed : 0;
          progressSamples.current[id] = { bytes: progress.totalBytesWritten, at: now };
          const total = Math.max(0, progress.totalBytesExpectedToWrite, probe.totalBytes);
          updateDownload(id, {
            status: 'downloading',
            transferredBytes: progress.totalBytesWritten,
            totalBytes: total,
            speedBytesPerSecond: speed,
            etaSeconds: speed > 0 && total > progress.totalBytesWritten
              ? Math.ceil((total - progress.totalBytesWritten) / speed) : undefined,
          });
        },
      );
      tasks.current[id] = task;
      try {
        const result = await task.downloadAsync();
        if (!result) {
          // pauseAsync() can resolve the original download promise with null.
          // Do not overwrite the paused state with cancelled in that case.
          updateData((current) => ({
            ...current,
            downloads: current.downloads.map((entry) =>
              entry.id === id && entry.status !== 'paused'
                ? { ...entry, status: 'cancelled' }
                : entry,
            ),
          }));
        } else if (result.status < 200 || result.status >= 300) {
          throw new Error(`The server returned HTTP ${result.status}.`);
        } else {
          const fileInfo = await getInfoAsync(fileUri);
          updateDownload(id, {
            status: 'completed',
            transferredBytes: fileInfo.exists ? fileInfo.size : 0,
            totalBytes: fileInfo.exists ? fileInfo.size : 0,
            resumeData: undefined,
          });
          if (isSupportedGameFile(fileName) && fileInfo.exists) {
            updateData((current) => ({
              ...current,
              files: [
                newVaultFile(fileName, fileUri, fileInfo.size, 'download'),
                ...current.files,
              ],
            }));
          }
          logActivity(`Download completed: ${fileName}`, 'download');
          delete tasks.current[id];
          delete progressSamples.current[id];
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Download failed.';
        const current = data.downloads.find((entry) => entry.id === id);
        if (current?.status !== 'paused') {
          updateDownload(id, { status: 'failed', error: message });
          logActivity(`Download failed: ${fileName}`, 'system');
          delete tasks.current[id];
          delete progressSamples.current[id];
        }
      }
      return id;
    },
    [data.downloads, logActivity, updateData, updateDownload],
  );

  const pauseDownload = useCallback(
    async (id: string) => {
      const task = tasks.current[id];
      if (!task) return;
      try {
        const saved = await task.pauseAsync();
        tasks.current[id] = task;
        updateDownload(id, {
          status: 'paused',
          resumeData: saved.resumeData,
          speedBytesPerSecond: 0,
          etaSeconds: undefined,
          error: saved.resumeData ? undefined : 'iOS did not provide a resume checkpoint. Resuming may restart this file from the beginning.',
        });
      } catch {
        updateDownload(id, { status: 'failed', error: 'This server does not support pausing this download.' });
      }
    },
    [updateDownload],
  );

  const resumeDownload = useCallback(
    async (id: string) => {
      const record = data.downloads.find((entry) => entry.id === id);
      if (!record) return;
      let task = tasks.current[id];
      if (!task) {
          task = createDownloadResumable(
          record.url,
          record.fileUri,
          { sessionType: FileSystemSessionType.FOREGROUND },
          (progress) => {
            const now = Date.now();
            const previous = progressSamples.current[id];
            const elapsed = previous ? Math.max(0.25, (now - previous.at) / 1000) : 0;
            const speed = previous && progress.totalBytesWritten >= previous.bytes
              ? (progress.totalBytesWritten - previous.bytes) / elapsed : 0;
            progressSamples.current[id] = { bytes: progress.totalBytesWritten, at: now };
            const total = Math.max(0, progress.totalBytesExpectedToWrite, record.totalBytes);
            updateDownload(id, {
              status: 'downloading',
              transferredBytes: progress.totalBytesWritten,
              totalBytes: total,
              speedBytesPerSecond: speed,
              etaSeconds: speed > 0 && total > progress.totalBytesWritten
                ? Math.ceil((total - progress.totalBytesWritten) / speed) : undefined,
            });
          },
          record.resumeData,
        );
        tasks.current[id] = task;
      } else {
        updateDownload(id, { status: 'downloading', error: undefined });
      }
      updateDownload(id, { status: 'downloading', error: undefined });
      try {
        const result = record.resumeData ? await task.resumeAsync() : await task.downloadAsync();
        if (result && result.status >= 200 && result.status < 300) {
          const fileInfo = await getInfoAsync(record.fileUri);
          updateDownload(id, {
            status: 'completed',
            transferredBytes: fileInfo.exists ? fileInfo.size : 0,
            totalBytes: fileInfo.exists ? fileInfo.size : 0,
            resumeData: undefined,
          });
          if (isSupportedGameFile(record.fileName) && fileInfo.exists) {
            updateData((current) => ({
              ...current,
              files: [
                newVaultFile(record.fileName, record.fileUri, fileInfo.size, 'download'),
                ...current.files.filter((file) => file.uri !== record.fileUri),
              ],
            }));
          }
          logActivity(`Download completed: ${record.fileName}`, 'download');
          delete tasks.current[id];
          delete progressSamples.current[id];
        } else if (!result) {
          updateDownload(id, { status: 'cancelled' });
        } else {
          throw new Error(`The server returned HTTP ${result.status}.`);
        }
      } catch (error) {
        updateDownload(id, {
          status: 'failed',
          error: error instanceof Error ? error.message : 'Download failed.',
        });
      }
    },
    [data.downloads, logActivity, updateData, updateDownload],
  );

  const cancelDownload = useCallback(
    async (id: string) => {
      const task = tasks.current[id];
      const record = data.downloads.find((entry) => entry.id === id);
      if (task) {
        try {
          await task.cancelAsync();
        } catch {
          // The task may already have completed or been cancelled.
        }
        delete tasks.current[id];
      }
      delete progressSamples.current[id];
      if (record?.fileUri) {
        try {
          await deleteAsync(record.fileUri, { idempotent: true });
        } catch {
          // A missing partial file is already in the desired state.
        }
      }
      updateDownload(id, { status: 'cancelled', resumeData: undefined });
    },
    [data.downloads, updateDownload],
  );

  const value = useMemo(
    () => ({
      data,
      ready,
      persistenceError,
      updateData,
      logActivity,
      startDownload,
      pauseDownload,
      resumeDownload,
      cancelDownload,
    }),
    [
      data,
      ready,
      persistenceError,
      updateData,
      logActivity,
      startDownload,
      pauseDownload,
      resumeDownload,
      cancelDownload,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppState(): AppContextValue {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppState must be used inside AppStateProvider.');
  return context;
}

export function createEmptyData(): AppData {
  return initialAppData();
}
