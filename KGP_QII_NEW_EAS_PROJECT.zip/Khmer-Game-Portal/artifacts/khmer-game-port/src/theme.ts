import { useMemo } from 'react';
import { useColors } from '@/hooks/useColors';
import { useAppState } from './state';

export const ACCENT_PALETTES = {
  gold: '#E5A52E',
  ember: '#F36A2D',
  jade: '#48B99B',
} as const;

export const ACCENT_OPTIONS = [
  { key: 'gold', name: 'Temple gold', color: ACCENT_PALETTES.gold },
  { key: 'ember', name: 'Ember orange', color: ACCENT_PALETTES.ember },
  { key: 'jade', name: 'Jade', color: ACCENT_PALETTES.jade },
] as const;

export function useAppColors() {
  const base = useColors();
  const { data } = useAppState();
  return useMemo(
    () => ({
      ...base,
      primary: ACCENT_PALETTES[data.preferences.accent],
      accent: ACCENT_PALETTES[data.preferences.accent],
      accentForeground: '#11100E',
      overlay: 'rgba(0,0,0,0.64)',
      handle: '#77736B',
      success: '#58C29B',
      text: base.foreground,
      tint: ACCENT_PALETTES[data.preferences.accent],
      background: '#0B0B0A',
      foreground: '#F3EFE8',
      card: '#161513',
      cardForeground: '#F3EFE8',
      secondary: '#211F1B',
      secondaryForeground: '#EDE6D8',
      muted: '#201E1A',
      mutedForeground: '#A39C90',
      border: '#312E28',
      input: '#312E28',
      destructive: '#EF665A',
      destructiveForeground: '#FFFFFF',
      radius: 18,
    }),
    [base, data.preferences.accent],
  );
}
