import {
  copyAsync,
  documentDirectory,
  EncodingType,
  getInfoAsync,
  makeDirectoryAsync,
  readAsStringAsync,
  writeAsStringAsync,
} from 'expo-file-system/legacy';
import { unzipSync, type UnzipFileInfo } from 'fflate';
import { makeId, type VaultFile } from './models';

const ROOT = 'khmer-game-port/';
const MAX_ZIP_BYTES = 25 * 1024 * 1024;
const MAX_UNPACKED_BYTES = 64 * 1024 * 1024;
const MAX_ZIP_ENTRIES = 300;

export const SUPPORTED_GAME_EXTENSIONS = ['zip', 'rar', '7z', 'ipa'] as const;

export function getExtension(name: string): string {
  const suffix = name.split('.').pop();
  return suffix && suffix !== name ? suffix.toLowerCase() : '';
}

export function isSupportedGameFile(name: string): boolean {
  return SUPPORTED_GAME_EXTENSIONS.includes(
    getExtension(name) as (typeof SUPPORTED_GAME_EXTENSIONS)[number],
  );
}

function safeFileName(name: string): string {
  const cleaned = name
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\.\.+/g, '_')
    .trim()
    .slice(0, 140);
  return cleaned || `file-${Date.now()}`;
}

function requireDocumentDirectory(): string {
  if (!documentDirectory) {
    throw new Error('Private file storage is unavailable in this preview.');
  }
  return documentDirectory;
}

async function ensureDirectory(uri: string): Promise<void> {
  const existing = await getInfoAsync(uri);
  if (!existing.exists) {
    await makeDirectoryAsync(uri, { intermediates: true });
  }
}

export async function copyToAppStorage(
  sourceUri: string,
  originalName: string,
  folder = 'files',
): Promise<{ uri: string; name: string; sizeBytes: number }> {
  const root = requireDocumentDirectory();
  const targetFolder = `${root}${ROOT}${folder}/`;
  await ensureDirectory(targetFolder);
  const name = `${Date.now()}-${safeFileName(originalName)}`;
  const uri = `${targetFolder}${name}`;
  const sourceInfo = await getInfoAsync(sourceUri);
  if (!sourceInfo.exists || sourceInfo.isDirectory) {
    throw new Error('The selected item is not an accessible file.');
  }
  await copyAsync({ from: sourceUri, to: uri });
  return { uri, name: safeFileName(originalName), sizeBytes: sourceInfo.size };
}

function bytesFromBase64(value: string): Uint8Array {
  const decoded = atob(value);
  const bytes = new Uint8Array(decoded.length);
  for (let index = 0; index < decoded.length; index += 1) {
    bytes[index] = decoded.charCodeAt(index);
  }
  return bytes;
}

function base64FromBytes(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

function isUnsafeArchivePath(path: string): boolean {
  const normalized = path.replace(/\\/g, '/');
  return (
    normalized.startsWith('/') ||
    /^[a-zA-Z]:/.test(normalized) ||
    normalized.split('/').some((segment) => segment === '..')
  );
}

export async function inspectAndExtractZip(
  archiveUri: string,
): Promise<VaultFile[]> {
  const info = await getInfoAsync(archiveUri);
  if (!info.exists || info.isDirectory) {
    throw new Error('The ZIP archive is no longer available.');
  }
  if (info.size > MAX_ZIP_BYTES) {
    throw new Error('ZIP extraction is limited to 25 MB compressed.');
  }
  const encoded = await readAsStringAsync(archiveUri, {
    encoding: EncodingType.Base64,
  });
  let entryCount = 0;
  let unpackedBytes = 0;

  const files = unzipSync(bytesFromBase64(encoded), {
    filter: (entry: UnzipFileInfo) => {
      entryCount += 1;
      if (entryCount > MAX_ZIP_ENTRIES) {
        throw new Error('This ZIP contains too many entries to inspect safely.');
      }
      if (isUnsafeArchivePath(entry.name)) {
        throw new Error('Unsafe archive path detected; nothing was extracted.');
      }
      unpackedBytes += entry.originalSize;
      if (unpackedBytes > MAX_UNPACKED_BYTES) {
        throw new Error('ZIP extraction is limited to 64 MB uncompressed.');
      }
      return !entry.name.endsWith('/');
    },
  });

  const entries = Object.entries(files);
  const usedNames = new Set<string>();
  const namedEntries = entries.map(([archivePath, contents]) => {
    const name = safeFileName(archivePath.replace(/\\/g, '/').split('/').pop() ?? '');
    if (!name || usedNames.has(name.toLowerCase())) {
      throw new Error('The ZIP contains duplicate filenames; nothing was extracted.');
    }
    usedNames.add(name.toLowerCase());
    return { name, contents };
  });

  const root = requireDocumentDirectory();
  const outputFolder = `${root}${ROOT}extracted/${Date.now()}/`;
  await ensureDirectory(outputFolder);
  const created: VaultFile[] = [];

  for (const { name, contents } of namedEntries) {
    const uri = `${outputFolder}${name}`;
    await writeAsStringAsync(uri, base64FromBytes(contents), {
      encoding: EncodingType.Base64,
    });
    created.push({
      id: makeId('file'),
      name,
      uri,
      sizeBytes: contents.byteLength,
      extension: getExtension(name),
      importedAt: Date.now(),
      source: 'extract',
    });
  }

  return created;
}

export function validateHttpsDownloadUrl(input: string): string {
  let parsed: URL;
  try {
    parsed = new URL(input.trim());
  } catch {
    throw new Error('Enter a complete HTTPS download link.');
  }
  const host = parsed.hostname.toLowerCase();
  const localOrPrivate =
    host === 'localhost' ||
    host.endsWith('.localhost') ||
    host.endsWith('.local') ||
    host === '::1' ||
    host === '0.0.0.0' ||
    /^127\./.test(host) ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^169\.254\./.test(host) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
    /^(fc|fd|fe80):/i.test(host);
  if (parsed.protocol !== 'https:' || localOrPrivate || !host || parsed.username || parsed.password) {
    throw new Error('Only public HTTPS links can be downloaded.');
  }
  return parsed.toString();
}

export function newVaultFile(
  name: string,
  uri: string,
  sizeBytes: number,
  source: VaultFile['source'],
): VaultFile {
  return {
    id: makeId('file'),
    name,
    uri,
    sizeBytes,
    extension: getExtension(name),
    importedAt: Date.now(),
    source,
  };
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value >= 10 ? 0 : 1)} ${units[unit]}`;
}
