# KHMER GAME PORT

Project by Qii Qii

A Khmer-first iOS companion for organizing local game profiles, user-selected files, direct downloads, mod notes, and control presets. The app uses Expo, React Native, TypeScript, and on-device persistence.

## Run

This app is managed by the `artifacts/khmer-game-port: expo` workflow. Use Replit's mobile preview or scan its QR code with Expo Go. For package and type checks:

```sh
pnpm --filter @workspace/khmer-game-port run typecheck
```

## What works in this build

- Five native-feeling tabs: Hub, Games, Files, Tools, and Settings.
- Game profile create, edit, favorite, search, and delete. Profiles and preferences persist on the device.
- Apple Files picker import for ZIP, RAR, 7Z, and IPA files into the app's private storage.
- ZIP path validation and extraction limits; IPA files are kept for inspection only.
- Direct HTTPS downloads with actual transfer progress, pause/resume when supported by the server, cancel, and a 500 MB transfer limit.
- Local mod metadata, editable control presets, and history. These do not modify game installations.
- Local audio-file import and playback.
- Backup export/restore for app metadata and preferences. The backup does not include game data or audio bytes.
- Public device/app information where iOS provides it, Khmer and English core labels, saved accent colors, a skippable original intro, and haptic feedback.
- Responsive layout configuration for iPhone and iPad.

## Local data and privacy

App records use AsyncStorage. User-selected files and app downloads are copied to private app storage. The app does not scan the device or contact a cloud service. Imported link targets and file sizes are checked before they are written locally. Never open or execute unknown downloaded content.

## Known platform limits

This is a React Native/Expo app, not the requested completed SwiftUI/Swift hybrid. It does not contain an Xcode project, a Swift native bridge, a game engine, or a signed IPA. iOS does not let an ordinary app install another IPA or inspect the whole filesystem. The Windows PC build of GTA V does not run natively on iOS. A compatible, authorized game port and native engine integration are not included.

See [`docs/feature-coverage.md`](docs/feature-coverage.md) for the status of all 49 sections in the supplied brief and [`docs/native-integration.md`](docs/native-integration.md) for what remains before a true native hybrid build.

## iOS release readiness

- App display name: **KHMER GAME PORT**
- Project credit: **Project by Qii Qii**
- Bundle identifier: `com.qiiqii.khmergameport`
- iOS permissions: user-selected documents only; microphone and background audio permissions are disabled.
- Build configuration and current status: [`docs/ios-build-readiness.md`](docs/ios-build-readiness.md)

## KGP Browser and Download Manager

- The Browser tab routes common file links and HTML `download` links into the in-app download queue. Some websites use JavaScript/blob streams, authentication flows, or custom redirects that cannot be intercepted as a normal direct URL.
- The queue supports multiple concurrent foreground downloads, progress, transfer speed, ETA, pause/resume, and cancel. Resume depends on the iOS download task and the server accepting byte-range requests; a server may force a restart.
- There is no application-level 100 GB cap. Actual maximum size depends on free device storage, iOS filesystem limits, server behavior, and the stability of the foreground app session. This build does not promise downloads will continue after iOS terminates the app or while it is suspended.
- The app is configured to stay in landscape orientation.


## Download engine notes

- Downloads use Expo FileSystem's foreground resumable downloader and store pause checkpoints when `pauseAsync()` succeeds.
- A paused download can resume from its saved checkpoint. If iOS terminates the app before a checkpoint is saved, the app marks the task as failed with a clear restart message instead of pretending it can resume.
- Progress, transfer speed, and ETA are estimates based on recent progress callbacks; ETA is unavailable when the server does not report a total size or transfer speed is not yet measurable.
- Resume depends on the remote server and its support for byte-range requests. This implementation does not guarantee background downloading, unlimited storage, or successful resume from every host. Large-file limits are ultimately constrained by available device storage and server behavior.


## Advanced download engine update

- Before starting, the app makes a metadata-only `HEAD` request (9-second timeout) to read `Content-Length`, `Accept-Ranges`, `ETag`, `Last-Modified`, `Content-Type`, and a server-provided filename when available. Hosts that reject `HEAD` are still allowed to proceed; their metadata is marked unknown.
- The queue displays whether the server advertises byte ranges. This is an advertisement check, not proof that every later range request will succeed.
- Pause checkpoints are saved when iOS returns resumable task data. If iOS supplies no checkpoint, the UI warns that resuming may restart from the beginning.
- The actual transfer remains Expo FileSystem's native foreground resumable task. It does not implement a custom chunked HTTP Range engine and cannot promise background continuation after iOS suspends or terminates the app. A signed-in/temporary hosting page is not automatically converted into a direct file URL.
