# iOS build readiness

## Project configuration

- App name: `KHMER GAME PORT`
- Project credit: `Project by Qii Qii`
- Bundle identifier: `com.qiiqii.khmergameport`
- Marketing version: `1.0.0`
- Initial iOS build number: `1`
- Tablet support: enabled
- Permission scope: no microphone, camera, location, photo-library, or background-audio access. Files are imported only after a user selects them through the system document picker. `expo-audio` microphone recording and background modes are disabled.

The bundle identifier is a proposed reverse-domain identifier based on the Qii Qii project name. Apple requires it to be unique in the developer account. Confirm its availability before the first iOS launch; after an app is registered with Apple, changing it may require creating a new app identifier.

## Current build status

**No IPA has been built.** The Expo configuration is prepared for Replit's supported iOS launch flow. This workspace has no `xcodebuild` or macOS SDK, so a local Xcode archive cannot be produced here.

Replit's Expo Launch flow builds in the cloud and submits the app to App Store Connect; it does not provide a direct IPA download for sideloading. Launching that flow requires an enrolled Apple Developer Program membership and the account access needed to register the app and create signing certificates and provisioning profiles. Add those through Replit's Apple account flow—do not put Apple credentials in project files or chat.

The initial iOS native project can be regenerated from the static `app.json` configuration with Expo prebuild. The `ios/` directory is ignored by Git because it is generated output; Replit Expo Launch uses the project configuration for its cloud build.

## Build checks

Run the app's type check and Expo dependency alignment check before starting an iOS launch. A successful check does not mean an IPA exists. The build should only be reported as complete after Replit confirms the cloud build and App Store Connect submission.
