# GTA V native engine integration status

## What this update adds

- A local Expo native module (`modules/gta-engine`) registered for iOS.
- A typed TypeScript API used by the Games screen to query native status and request Story/Sandbox launch.
- Honest runtime capability reporting. Story and Sandbox remain disabled until a real engine adapter is linked.
- Existing KGP QII files, download manager, screens, state model, and original project paths are retained.

## What is not included yet

This archive does **not** contain the upstream GTA V engine source, `game.wasm`, translated ARM64 engine objects, precompiled Metal shaders, ShaderTool outputs, Blink/WASM dependencies, or Rockstar game assets. Therefore it cannot run GTA V yet. The native bridge deliberately reports `engineLinked: false` and refuses to claim a successful launch.

## Upstream engine facts

The upstream project describes a build-time pipeline: translate the WebAssembly game engine to C with `wasm2c`, compile it for ARM64, translate/precompile shaders for its Metal renderer, and package the result with the app. iOS does not compile the game engine on-device. Game files must be supplied by the user; this project must not distribute copyrighted game data.

Upstream repository: https://github.com/kevinerikjs/gta5-ios-port

## Required next integration work

1. Obtain and inspect the complete upstream source at a pinned commit, including its license files and build scripts.
2. Identify the upstream app entry point and extract a reusable engine host/adapter instead of embedding a second app delegate or duplicate app target.
3. Add the upstream native sources, vendor dependencies and shader build steps to the KGP iOS target; preserve KGP's bundle identifier, Expo app delegate, navigation and download manager.
4. Add a security-scoped game-folder import or in-app file placement workflow, manifest validation and storage-space checks. Do not bundle game assets.
5. Implement the bridge's `getStatus` and `launch` against the actual engine host, then wire KGP graphics preferences, controller input and gyroscope input to the engine.
6. Build with Xcode on macOS, resolve signing/entitlements and test on physical devices.

## Build note

After adding this local Expo module, regenerate/install iOS native dependencies on macOS (`npx expo prebuild -p ios` or the project's normal native generation workflow, then `pod install`). Do not run prebuild over a customized native project without a backup/review. A source ZIP alone cannot prove an iOS build or gameplay.
