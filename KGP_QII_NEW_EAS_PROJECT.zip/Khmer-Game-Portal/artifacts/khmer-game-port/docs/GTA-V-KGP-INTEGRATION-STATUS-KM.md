# ស្ថានភាពភ្ជាប់ GTA V ទៅ KGP QII

## អ្វីដែលបានធ្វើក្នុង Project នេះ

- រក្សា source និង folder ដើមរបស់ KGP QII។
- ដាក់ source repository `kevinerikjs/gta5-ios-port` ទាំងមូលក្នុង `vendor/gta5-ios-port-upstream/`។
- បន្ថែម Expo Native Module `modules/gta-engine/` ជា boundary រវាង React Native និង native iOS code។
- Games screen បង្ហាញស្ថានភាព source, build inputs, WASM/ARM64, Metal និង game files ដោយមិនអះអាងថា engine រួចរាល់។
- ការចុច Story Mode / Sandbox នឹងបដិសេធដោយសុវត្ថិភាព ប្រសិនបើ runtime មិនទាន់ភ្ជាប់។

## អ្វីដែល Source ZIP ផ្តល់ និងអ្វីដែលខ្វះ

Source ZIP មាន Swift/Objective-C/C/C++ source, Metal renderer, app project.yml, build scripts និងឯកសារណែនាំ។ ប៉ុន្តែ project.yml សំដៅទៅ `app/Generated/`, `app/GeneratedResources/` និង `app/Tools/wabt-1.0.42/` ដែលមិនមានក្នុង ZIP ដែលបានផ្ញើ។ `build_ipa.sh` ក៏ត្រូវការ Apple Silicon Mac, Xcode, xcodegen និង game files ដែលមានសិទ្ធិប្រើ។

## ហេតុអ្វីមិនអាចបញ្ចូល Engine ដោយចម្លង folder តែមួយ

Upstream project មាន target `PlayGTA5Native` ប្រភេទ `application` ជាមួយ AppDelegate, SceneDelegate, renderer និង engine host ផ្ទាល់ខ្លួន។ KGP QII វិញជា Expo/React Native app មាន bundle ID និង lifecycle ផ្សេង។ ដូច្នេះការចម្លង Swift source ទៅក្នុង Pod មិនបង្កើត GTA runtime ទេ។ ត្រូវបំបែក/រៀបចំ engine ជា library target និងភ្ជាប់ native lifecycle, renderer, asset paths និង input events ឱ្យត្រឹមត្រូវជាមុន។

## ការត្រូវការដើម្បីបន្ត

1. បង្កើត ឬទាញយក generated WASM-to-C engine និង WABT toolchain តាម upstream build process។
2. បង្កើត library target សម្រាប់ engine/Metal renderer (មិនមែនដាក់ app target មួយនៅក្នុង app មួយទៀត)។
3. បង្កើត adapter សម្រាប់ lifecycle, file access, audio, touch/controller និង graphics settings។
4. ភ្ជាប់ library target ទៅ Expo native module របស់ KGP QII។
5. Build ជាមួយ Xcode លើ macOS ហើយសាកល្បងលើ iPhone ពិត។

## ការរក្សាឯកសារ

Source import និងការកែប្រែនេះបន្ថែមឯកសារ/កូដថ្មីប៉ុណ្ណោះ។ មិនលុបឯកសារដើម KGP QII ទេ។
