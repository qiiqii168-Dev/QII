# GTA V iOS integration plan for KGP QII

## What this update adds
- A GTA V iOS Port status panel in the Games screen.
- Story Mode and Sandbox entry points that clearly explain why launch is unavailable until a runtime is integrated.
- Persistent graphics preference selectors: Performance/Balanced/Quality, Native/720p/1080p, and 30/60/120 FPS.
- Existing touch-control presets, mod records, and game-file library remain part of KGP QII.

## What is not integrated
This project is currently an Expo/React Native app. It does not contain the GTA V WebAssembly runtime, ARM64 translation/runtime layer, Metal renderer, native game loop, audio/input bridge, or game-specific save/mod loader. The new graphics choices are stored preferences only; they do not change actual rendering or frame rate. Story Mode and Sandbox do not launch a game.

## Required engineering work before gameplay
1. Audit and pin a specific upstream GTA V iOS Port commit and its license/dependency notices.
2. Build the upstream engine for iOS device architectures in a reproducible macOS/Xcode environment.
3. Add a native iOS module/view to host the Metal renderer and engine lifecycle.
4. Define a typed React Native bridge for launch, pause/resume, graphics settings, controller input, gyroscope input, and runtime status.
5. Implement storage access for user-provided game data without copying a 20+ GB directory into JavaScript memory. Validate free space and use streaming/file URLs.
6. Connect controller and motion input using native iOS GameController and CoreMotion APIs, then map touch controls to the same input interface.
7. Add engine-aware mod/cheat support only where the upstream engine explicitly supports it and where user-provided files are validated.
8. Test on physical devices, including memory pressure, thermal behavior, interrupted file imports, and app lifecycle transitions.

## Important limits
- iOS sandboxing does not permit scanning arbitrary folders across the iPhone. Users must explicitly select files/folders through supported document-picker APIs.
- The existing ZIP extraction utility is intentionally bounded (25 MB compressed / 64 MB unpacked); it is not suitable for a 21 GB game archive.
- FPS/resolution options are preferences until the native renderer consumes them.
- No GTA V game assets are included. Users must supply game data they are legally entitled to use.
- A successful TypeScript build does not prove that the native game engine builds or runs.
