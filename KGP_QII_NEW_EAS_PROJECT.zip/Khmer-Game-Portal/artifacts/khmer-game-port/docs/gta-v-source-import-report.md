# GTA V iOS Port source import report

## What was added

The complete source archive supplied by the user (`gta5-ios-port-main.zip`) has been copied into:

`vendor/gta5-ios-port-upstream/`

The upstream repository's README, MIT license, app sources, build scripts, shader tooling, vendor dependencies, and documentation are retained in that folder. The upstream source is kept separate from KGP's Expo app so its own iOS app entry points and build settings do not overwrite KGP's app configuration.

## What this does and does not mean

- The upstream source code is now present in the KGP project as a vendored reference/integration source tree.
- KGP's existing `modules/gta-engine` bridge remains a safe placeholder and continues to report that the engine is not linked.
- This import does **not** yet make GTA V launch from KGP.
- No GTA V game files, `game.wasm`, translated generated engine C files, generated Metal shaders, or user game assets are included in the supplied source archive.
- The upstream build script requires an Apple Silicon Mac, Xcode, XcodeGen, Python tooling, and the user's own compatible game-file folder to run its preparation/build pipeline.
- The upstream app is a standalone native iOS application. Merging it into KGP requires extracting and adapting its engine host, renderer, lifecycle, input and resource setup into KGP's Expo-generated iOS target; copying its whole app target into KGP would create conflicting app entry points and bundle settings.

## Integration steps still required

1. Pin and record the exact upstream Git commit used for the vendored source.
2. On macOS, run the upstream game-file validation and preparation pipeline using the user's own game files.
3. Identify the minimal engine/renderer source and generated outputs required by KGP.
4. Adapt the native engine host to KGP's Expo iOS lifecycle and preserve KGP's bundle identifier, app delegate, navigation and download manager.
5. Connect KGP's Story/Sandbox launch requests, graphics/FPS settings, touch/controller input and gyroscope input to the real engine API.
6. Build with Xcode, resolve signing and entitlements, then test on a physical iPhone.

## Licensing and game assets

The upstream source tree includes its MIT license and third-party license notices. Those notices must remain with any redistributed source. The upstream README states that the repository contains no Rockstar game files or game code; users must supply their own game files. Do not bundle or redistribute copyrighted GTA V assets.

## Validation

- The supplied upstream ZIP passed ZIP integrity validation.
- The KGP source archive was retained and extended; no existing KGP archive entries were intentionally removed or overwritten.
- No Xcode/iOS build or physical-device gameplay test was possible in this environment.
