# Native iOS integration: remaining work

The current project is one Expo/React Native application. It intentionally reports the game engine as unavailable instead of exposing fake launch, input, graphics, or save operations.

## Required before a Swift/engine release

1. Work from a macOS host with Xcode and the iOS SDK. This Replit build environment does not produce or sign an Xcode archive.
2. Add a compatible, maintained engine runtime (for example, a project-specific Godot or Unity iOS integration) and confirm its licenses, device requirements, and distribution terms.
3. Obtain authorized source code and assets for the target game. GTA V PC assets or executables are not an iOS port and cannot be bundled or executed by this project.
4. Add the engine as an iOS native target using Expo Modules API or a documented React Native native module. Keep native engine lifecycle and rendering code outside the React Native UI layer.
5. Define typed bridge contracts for engine availability, launch/session state, input events, pause/resume, errors, and supported graphics properties. Emit progress only from the real engine.
6. Add permission descriptions and the minimum required entitlements in a static Expo configuration/plugin, then generate and review the native iOS project on macOS.
7. Implement shared profile persistence and migration semantics before syncing native records with AsyncStorage. Never sync file URLs from one device as if they worked on another.
8. Test on the iOS Simulator and physical supported devices. Verify lifecycle interruption, orientation, file access, bridge errors, engine startup, and touch input before enabling launch controls.
9. Configure an Apple-supported signing and distribution process in Xcode. Do not put Apple credentials in source control or this app's metadata.

## Existing integration boundary

- React Native/Expo owns navigation, profiles, preferences, control metadata, history, and local file records.
- The Files picker grants access only to items the user selects; imported copies are stored in this app's private container.
- ZIP parsing/extraction is local and bounded. RAR/7Z are catalogued but not extracted.
- IPA is a file format for inspection and backup only. iOS does not allow this app to install an arbitrary IPA.
- Downloads are initiated by the user's direct HTTPS URL. The app does not bypass authentication, paywalls, CAPTCHA, or provider rules.
- `Game engine: Not installed` is the truthful state until a real native integration is added.

## Build limitation

The current deliverable is not an Xcode workspace, an App Store archive, or a signed IPA. A native project should only be generated after the engine dependency, native module, bundle identifier, permission descriptions, and target iOS devices are settled on a Mac. No signing credentials were requested or stored.
