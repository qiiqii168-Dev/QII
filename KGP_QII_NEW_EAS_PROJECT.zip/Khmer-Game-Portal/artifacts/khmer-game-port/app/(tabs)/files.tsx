export { default } from '@/components/screens/FilesScreen';
