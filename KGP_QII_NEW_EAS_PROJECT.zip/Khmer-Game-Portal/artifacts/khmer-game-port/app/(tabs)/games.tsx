export { default } from '@/components/screens/GamesScreen';
