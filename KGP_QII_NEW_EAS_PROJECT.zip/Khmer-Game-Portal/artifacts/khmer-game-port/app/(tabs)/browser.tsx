export { default } from '@/components/screens/BrowserScreen';
