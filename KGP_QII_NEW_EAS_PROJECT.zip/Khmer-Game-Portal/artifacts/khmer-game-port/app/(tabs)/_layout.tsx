import React from 'react';
import { Platform, StyleSheet, useColorScheme, View } from 'react-native';
import { useAppColors } from '@/src/theme';
import { Feather } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { isLiquidGlassAvailable } from 'expo-glass-effect';
import { Tabs } from 'expo-router';
import { NativeTabs } from 'expo-router/native-tabs';
import { SymbolView } from 'expo-symbols';
import { useLabels } from '@/src/i18n';

// IMPORTANT: iOS 26 uses NativeTabs for native tabs with liquid glass support.
// NativeTabs intentionally does NOT use custom design tokens — liquid glass
// is a system-level appearance provided by iOS and cannot be overridden.
// Custom brand colors are applied only on the ClassicTabLayout path (older iOS / Android / web).
function NativeTabLayout() {
  const labels = useLabels();
  return (
    <NativeTabs>
      <NativeTabs.Trigger name="index">
        <NativeTabs.Trigger.Icon
          sf={{ default: 'house', selected: 'house.fill' }}
        />
        <NativeTabs.Trigger.Label>{labels.home}</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="games">
        <NativeTabs.Trigger.Icon sf={{ default: 'gamecontroller', selected: 'gamecontroller.fill' }} />
        <NativeTabs.Trigger.Label>{labels.games}</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="browser">
        <NativeTabs.Trigger.Icon sf={{ default: 'globe', selected: 'globe' }} />
        <NativeTabs.Trigger.Label>Browser</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="files">
        <NativeTabs.Trigger.Icon sf={{ default: 'folder', selected: 'folder.fill' }} />
        <NativeTabs.Trigger.Label>{labels.files}</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="tools">
        <NativeTabs.Trigger.Icon sf={{ default: 'wrench.and.screwdriver', selected: 'wrench.and.screwdriver.fill' }} />
        <NativeTabs.Trigger.Label>{labels.tools}</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="settings">
        <NativeTabs.Trigger.Icon sf={{ default: 'gearshape', selected: 'gearshape.fill' }} />
        <NativeTabs.Trigger.Label>{labels.settings}</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}

function ClassicTabLayout() {
  const colors = useAppColors();
  const labels = useLabels();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const isIOS = Platform.OS === 'ios';
  const isWeb = Platform.OS === 'web';

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarStyle: {
          position: 'absolute',
          backgroundColor: isIOS ? 'transparent' : colors.background,
          borderTopWidth: isWeb ? 1 : 0,
          borderTopColor: colors.border,
          elevation: 0,
          ...(isWeb ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={100}
              tint={isDark ? 'dark' : 'light'}
              style={StyleSheet.absoluteFill}
            />
          ) : isWeb ? (
            <View
              style={[
                StyleSheet.absoluteFill,
                { backgroundColor: colors.background },
              ]}
            />
          ) : null,
      }}
    >
      <Tabs.Screen name="index" options={{ title: labels.home, tabBarIcon: ({ color, focused }) => isIOS ? <SymbolView name="house" tintColor={color} size={22} /> : <Feather name="home" size={20} color={focused ? colors.primary : colors.mutedForeground} /> }} />
      <Tabs.Screen name="games" options={{ title: labels.games, tabBarIcon: ({ color, focused }) => isIOS ? <SymbolView name="gamecontroller" tintColor={color} size={22} /> : <Feather name="grid" size={20} color={focused ? colors.primary : colors.mutedForeground} /> }} />
      <Tabs.Screen name="browser" options={{ title: 'Browser', tabBarIcon: ({ color, focused }) => isIOS ? <SymbolView name="globe" tintColor={color} size={22} /> : <Feather name="globe" size={20} color={focused ? colors.primary : colors.mutedForeground} /> }} />
      <Tabs.Screen name="files" options={{ title: labels.files, tabBarIcon: ({ color, focused }) => isIOS ? <SymbolView name="folder" tintColor={color} size={22} /> : <Feather name="folder" size={20} color={focused ? colors.primary : colors.mutedForeground} /> }} />
      <Tabs.Screen name="tools" options={{ title: labels.tools, tabBarIcon: ({ color, focused }) => isIOS ? <SymbolView name="wrench.and.screwdriver" tintColor={color} size={22} /> : <Feather name="tool" size={20} color={focused ? colors.primary : colors.mutedForeground} /> }} />
      <Tabs.Screen name="settings" options={{ title: labels.settings, tabBarIcon: ({ color, focused }) => isIOS ? <SymbolView name="gearshape" tintColor={color} size={22} /> : <Feather name="settings" size={20} color={focused ? colors.primary : colors.mutedForeground} /> }} />
    </Tabs>
  );
}

export default function TabLayout() {
  if (isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}
