import React, { useEffect, useState } from 'react';
import {
  Alert,
  Linking,
  Pressable,
  StyleSheet,
  Switch,
  View,
} from 'react-native';
import { router } from 'expo-router';
import * as Application from 'expo-application';
import { Ionicons } from '@expo/vector-icons';
import { ActionButton, AppText, FormField, Panel, Screen, SectionTitle, Tag } from '@/components/ui';
import { useAppState } from '@/src/state';
import { ACCENT_OPTIONS, useAppColors } from '@/src/theme';
import { localize, useLabels } from '@/src/i18n';

export default function SettingsScreen() {
  const colors = useAppColors();
  const labels = useLabels();
  const { data, updateData, logActivity, persistenceError } = useAppState();
  const language = data.preferences.language;
  const [playerName, setPlayerName] = useState(data.preferences.playerName);

  useEffect(() => {
    setPlayerName(data.preferences.playerName);
  }, [data.preferences.playerName]);

  const updatePreference = <K extends keyof typeof data.preferences>(
    key: K,
    value: (typeof data.preferences)[K],
  ) => {
    updateData((current) => ({
      ...current,
      preferences: { ...current.preferences, [key]: value },
    }));
    logActivity(`Changed preference: ${key}`, 'settings');
  };

  const saveProfile = () => {
    updateData((current) => ({
      ...current,
      preferences: { ...current.preferences, playerName: playerName.trim() },
    }));
    logActivity('Updated player profile name', 'settings');
    Alert.alert(
      localize(language, 'Profile saved', 'បានរក្សាទុកប្រវត្តិរូប'),
      localize(language, 'Your display name is stored on this device.', 'ឈ្មោះបង្ហាញរបស់អ្នកត្រូវបានរក្សាទុកក្នុងឧបករណ៍នេះ។'),
    );
  };

  const previewIntro = () => {
    updateData((current) => ({
      ...current,
      preferences: { ...current.preferences, introSeen: false, introEnabled: true },
    }));
    router.navigate('/');
  };

  const resetPreferences = () => {
    Alert.alert(
      localize(language, 'Reset preferences?', 'កំណត់ចំណូលចិត្តឡើងវិញ?'),
      localize(language, 'This restores language, colors, intro, and touch feedback defaults. Game profiles and files are not deleted.', 'វាស្ដារភាសា ពណ៌ វីដេអូណែនាំ និងមតិត្រឡប់ពេលប៉ះ។ ប្រវត្តិរូបហ្គេម និងឯកសារមិនត្រូវបានលុបទេ។'),
      [
        { text: localize(language, 'Keep settings', 'រក្សាការកំណត់'), style: 'cancel' },
        {
          text: localize(language, 'Reset', 'កំណត់ឡើងវិញ'),
          style: 'destructive',
          onPress: () => {
            updateData((current) => ({
              ...current,
              preferences: {
                introEnabled: true,
                introSeen: true,
                hapticsEnabled: true,
                language: 'km',
                accent: 'gold',
                playerName: '',
              },
            }));
            logActivity('Reset app preferences', 'settings');
          },
        },
      ],
    );
  };

  return (
    <Screen>
      <View style={{ gap: 5 }}>
        <AppText style={{ color: colors.primary, fontSize: 11, letterSpacing: 1.5 }}>
          {localize(language, 'YOUR APP', 'កម្មវិធីរបស់អ្នក')}
        </AppText>
        <AppText weight="bold" style={{ color: colors.foreground, fontSize: 29 }}>{labels.settings}</AppText>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Player profile', 'ប្រវត្តិរូបអ្នកលេង')} />
        <Panel style={{ gap: 13 }}>
          <View style={styles.profileHead}>
            <View style={[styles.avatar, { backgroundColor: `${colors.primary}20` }]}>
              <Ionicons name="person-outline" size={21} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
                {data.preferences.playerName || localize(language, 'Player', 'អ្នកលេង')}
              </AppText>
              <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                {localize(language, 'Local profile · no account', 'ប្រវត្តិរូបក្នុងឧបករណ៍ · គ្មានគណនី')}
              </AppText>
            </View>
            <Tag label={localize(language, 'ON DEVICE', 'ក្នុងឧបករណ៍')} />
          </View>
          <FormField
            label={localize(language, 'Display name', 'ឈ្មោះបង្ហាញ')}
            value={playerName}
            onChangeText={setPlayerName}
            placeholder={localize(language, 'Choose a display name', 'ជ្រើសឈ្មោះបង្ហាញ')}
          />
          <ActionButton label={localize(language, 'Save profile', 'រក្សាទុកប្រវត្តិរូប')} icon="checkmark" onPress={saveProfile} />
          <AppText style={{ color: colors.mutedForeground, fontSize: 10, lineHeight: 16 }}>
            {localize(language, 'Play time and achievements are not available until a compatible engine is connected.', 'មិនអាចបង្ហាញពេលលេង និងសមិទ្ធផលទេ រហូតដល់មានម៉ាស៊ីនហ្គេមដែលគាំទ្រ។')}
          </AppText>
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={labels.preferences} />
        <Panel style={{ gap: 15 }}>
          <SettingsSwitch
            icon="film-outline"
            title={labels.intro}
            detail={localize(language, 'Show the intro the next time this app opens', 'បង្ហាញវីដេអូណែនាំនៅពេលបើកកម្មវិធីលើកក្រោយ')}
            value={data.preferences.introEnabled}
            onValueChange={(value) => updatePreference('introEnabled', value)}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SettingsSwitch
            icon="hand-left-outline"
            title={labels.haptics}
            detail={localize(language, 'Use a light touch response on important actions', 'ប្រើការឆ្លើយតបពេលប៉ះលើសកម្មភាពសំខាន់ៗ')}
            value={data.preferences.hapticsEnabled}
            onValueChange={(value) => updatePreference('hapticsEnabled', value)}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <View style={styles.settingRow}>
            <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
              <Ionicons name="language-outline" size={17} color={colors.primary} />
            </View>
            <View style={{ flex: 1, gap: 3 }}>
              <AppText weight="medium" style={{ color: colors.foreground, fontSize: 12 }}>{labels.language}</AppText>
              <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                {data.preferences.language === 'km' ? 'ភាសាខ្មែរ' : 'English'}
              </AppText>
            </View>
            <View style={[styles.choiceGroup, { backgroundColor: colors.background }]}>
              <LanguageChoice
                label="EN"
                active={data.preferences.language === 'en'}
                onPress={() => updatePreference('language', 'en')}
              />
              <LanguageChoice
                label="ខ្មែរ"
                active={data.preferences.language === 'km'}
                onPress={() => updatePreference('language', 'km')}
              />
            </View>
          </View>
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Accent color', 'ពណ៌សង្កត់ធ្ងន់')} />
        <Panel style={{ gap: 14 }}>
          <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>
            {localize(language, 'Changes the app’s active highlight color.', 'ប្ដូរពណ៌សង្កត់ធ្ងន់របស់កម្មវិធី។')}
          </AppText>
          <View style={styles.accentRow}>
            {ACCENT_OPTIONS.map((accent) => {
              const active = data.preferences.accent === accent.key;
              return (
                <Pressable
                  key={accent.key}
                  accessibilityRole="button"
                  accessibilityLabel={`Use ${accent.name}`}
                  onPress={() => updatePreference('accent', accent.key)}
                  style={[
                    styles.accentChoice,
                    {
                      borderColor: active ? accent.color : colors.border,
                      backgroundColor: active ? `${accent.color}18` : colors.background,
                    },
                  ]}
                >
                  <View style={[styles.accentDot, { backgroundColor: accent.color }]} />
                  <AppText style={{ color: active ? colors.foreground : colors.mutedForeground, fontSize: 10 }}>
                    {accent.name}
                  </AppText>
                </Pressable>
              );
            })}
          </View>
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Game graphics profile', 'ការកំណត់ក្រាហ្វិកហ្គេម')} />
        <Panel style={{ gap: 13 }}>
          <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
            {localize(language, 'These values are saved as your preferred profile. They will affect rendering only after a compatible native game engine is connected.', 'ការកំណត់ទាំងនេះត្រូវបានរក្សាទុកជាចំណូលចិត្តប៉ុណ្ណោះ។ វានឹងប៉ះពាល់ដល់ក្រាហ្វិកនៅពេលភ្ជាប់ Native Game Engine ដែលត្រូវគ្នា។')}
          </AppText>
          <AppText weight="medium" style={{ color: colors.foreground, fontSize: 12 }}>
            {localize(language, 'Quality preset', 'គុណភាពក្រាហ្វិក')}
          </AppText>
          <View style={styles.accentRow}>
            {([
              ['performance', 'Performance', 'ល្បឿន'],
              ['balanced', 'Balanced', 'សមតុល្យ'],
              ['quality', 'Quality', 'គុណភាព'],
            ] as const).map(([value, en, km]) => {
              const active = (data.preferences.graphicsPreset ?? 'balanced') === value;
              return (
                <Pressable
                  key={value}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                  onPress={() => updatePreference('graphicsPreset', value)}
                  style={[styles.accentChoice, { borderColor: active ? colors.primary : colors.border, backgroundColor: active ? `${colors.primary}18` : colors.background }]}
                >
                  <AppText weight={active ? 'bold' : 'regular'} style={{ color: active ? colors.foreground : colors.mutedForeground, fontSize: 10 }}>
                    {localize(language, en, km)}
                  </AppText>
                </Pressable>
              );
            })}
          </View>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <AppText weight="medium" style={{ color: colors.foreground, fontSize: 12 }}>
            {localize(language, 'Resolution target', 'គោលដៅ Resolution')}
          </AppText>
          <View style={styles.accentRow}>
            {([
              ['native', 'Native'],
              ['720p', '720p'],
              ['1080p', '1080p'],
            ] as const).map(([value, label]) => {
              const active = (data.preferences.resolutionTarget ?? 'native') === value;
              return (
                <Pressable key={value} accessibilityRole="button" accessibilityState={{ selected: active }}
                  onPress={() => updatePreference('resolutionTarget', value)}
                  style={[styles.accentChoice, { borderColor: active ? colors.primary : colors.border, backgroundColor: active ? `${colors.primary}18` : colors.background }]}
                >
                  <AppText weight={active ? 'bold' : 'regular'} style={{ color: active ? colors.foreground : colors.mutedForeground, fontSize: 10 }}>{label}</AppText>
                </Pressable>
              );
            })}
          </View>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <AppText weight="medium" style={{ color: colors.foreground, fontSize: 12 }}>
            {localize(language, 'Frame rate target', 'គោលដៅ FPS')}
          </AppText>
          <View style={styles.accentRow}>
            {([30, 60, 120] as const).map((value) => {
              const active = (data.preferences.frameRateTarget ?? 60) === value;
              return (
                <Pressable key={value} accessibilityRole="button" accessibilityState={{ selected: active }}
                  onPress={() => updatePreference('frameRateTarget', value)}
                  style={[styles.accentChoice, { borderColor: active ? colors.primary : colors.border, backgroundColor: active ? `${colors.primary}18` : colors.background }]}
                >
                  <AppText weight={active ? 'bold' : 'regular'} style={{ color: active ? colors.foreground : colors.mutedForeground, fontSize: 10 }}>{value} FPS</AppText>
                </Pressable>
              );
            })}
          </View>
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Intro', 'វីដេអូណែនាំ')} />
        <Panel style={{ gap: 11 }}>
          <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
            {localize(language, 'The intro shows the Khmer-inspired artwork and waits for your choice. It does not display a fake loading bar.', 'វីដេអូណែនាំបង្ហាញស្នាដៃសិល្បៈបែបខ្មែរ ហើយរង់ចាំជម្រើសរបស់អ្នក។ វាមិនបង្ហាញរបារផ្ទុកក្លែងក្លាយទេ។')}
          </AppText>
          <ActionButton label={localize(language, 'Preview intro', 'មើលវីដេអូណែនាំ')} icon="play-outline" secondary onPress={previewIntro} />
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title="Supporter" />
        <Panel style={{ gap: 10 }}>
          <View style={styles.profileHead}>
            <View style={[styles.avatar, { backgroundColor: `${colors.primary}20` }]}><Ionicons name="paper-plane" size={21} color={colors.primary} /></View>
            <View style={{ flex: 1, gap: 3 }}>
              <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>Qii Qii</AppText>
              <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>@qiiqii168</AppText>
            </View>
          </View>
          <ActionButton label="Contact on Telegram" icon="paper-plane-outline" onPress={() => void Linking.openURL('https://t.me/qiiqii168')} />
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={labels.about} />
        <Panel style={{ gap: 12 }}>
          <AboutRow label={localize(language, 'App', 'កម្មវិធី')} value="KHMER GAME PORT" />
          <AboutRow label={localize(language, 'Project credit', 'ឥណទានគម្រោង')} value="Project by Qii Qii" />
          <AboutRow label={localize(language, 'App version', 'កំណែកម្មវិធី')} value={Application.nativeApplicationVersion ?? '1.0.0'} />
          <AboutRow label="Build" value={Application.nativeBuildVersion ?? '1'} />
          <AboutRow label={localize(language, 'Data storage', 'ទំហំផ្ទុកទិន្នន័យ')} value={localize(language, 'Private app storage on this device', 'ទំហំផ្ទុកឯកជនក្នុងឧបករណ៍នេះ')} />
          <AboutRow label={localize(language, 'Engine integration', 'ការភ្ជាប់ម៉ាស៊ីនហ្គេម')} value={localize(language, 'Not installed', 'មិនបានដំឡើង')} />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
            {localize(language, 'This app does not install IPA files, access the whole iPhone filesystem, or run PC game builds. Cloud sync is not configured.', 'កម្មវិធីនេះមិនដំឡើងឯកសារ IPA មិនចូលប្រើប្រព័ន្ធឯកសារ iPhone ទាំងមូល និងមិនដំណើរការហ្គេមកុំព្យូទ័រទេ។ មិនទាន់កំណត់សមកាលកម្មពពក។')}
          </AppText>
          {persistenceError ? (
            <View style={[styles.errorBox, { backgroundColor: `${colors.destructive}18` }]}>
              <Ionicons name="warning-outline" size={16} color={colors.destructive} />
              <AppText style={{ color: colors.destructive, flex: 1, fontSize: 10 }}>{persistenceError}</AppText>
            </View>
          ) : null}
          <ActionButton label={localize(language, 'Reset preferences', 'កំណត់ចំណូលចិត្តឡើងវិញ')} icon="refresh-outline" secondary onPress={resetPreferences} />
        </Panel>
      </View>
    </Screen>
  );
}

function SettingsSwitch({
  icon,
  title,
  detail,
  value,
  onValueChange,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  detail: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.settingRow}>
      <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
        <Ionicons name={icon} size={17} color={colors.primary} />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <AppText weight="medium" style={{ color: colors.foreground, fontSize: 12 }}>{title}</AppText>
        <AppText style={{ color: colors.mutedForeground, fontSize: 10, lineHeight: 15 }}>{detail}</AppText>
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: colors.border, true: `${colors.primary}A0` }}
        thumbColor={value ? colors.primary : colors.secondaryForeground}
      />
    </View>
  );
}

function LanguageChoice({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useAppColors();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={[
        styles.languageButton,
        active && { backgroundColor: colors.primary },
      ]}
    >
      <AppText weight={active ? 'bold' : 'regular'} style={{ color: active ? colors.accentForeground : colors.mutedForeground, fontSize: 10 }}>
        {label}
      </AppText>
    </Pressable>
  );
}

function AboutRow({ label, value }: { label: string; value: string }) {
  const colors = useAppColors();
  return (
    <View style={styles.aboutRow}>
      <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{label}</AppText>
      <AppText style={{ color: colors.foreground, fontSize: 11, textAlign: 'right' }}>{value}</AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  profileHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  avatar: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  divider: { height: StyleSheet.hairlineWidth },
  settingRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  settingIcon: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center', borderRadius: 12 },
  choiceGroup: { flexDirection: 'row', gap: 3, borderRadius: 12, padding: 3 },
  languageButton: { minWidth: 37, paddingHorizontal: 8, paddingVertical: 7, borderRadius: 9, alignItems: 'center' },
  accentRow: { flexDirection: 'row', gap: 8 },
  accentChoice: { flex: 1, gap: 8, alignItems: 'center', paddingVertical: 11, borderRadius: 13, borderWidth: 1 },
  accentDot: { width: 18, height: 18, borderRadius: 9 },
  aboutRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  errorBox: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 12 },
});
