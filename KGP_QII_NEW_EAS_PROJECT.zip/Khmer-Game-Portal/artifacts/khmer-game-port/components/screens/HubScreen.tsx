import React, { useEffect, useState } from 'react';
import {
  Alert,
  Image,
  ImageBackground,
  Modal,
  Pressable,
  StyleSheet,
  View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppText, ActionButton, Panel, Screen, SectionTitle, Tag } from '@/components/ui';
import { useAppState } from '@/src/state';
import { useAppColors } from '@/src/theme';
import { useLabels } from '@/src/i18n';
import { formatBytes } from '@/src/file-service';

export default function HubScreen() {
  const colors = useAppColors();
  const labels = useLabels();
  const { data, ready, updateData } = useAppState();
  const [introVisible, setIntroVisible] = useState(false);

  useEffect(() => {
    if (ready && data.preferences.introEnabled && !data.preferences.introSeen) {
      setIntroVisible(true);
    }
  }, [data.preferences.introEnabled, data.preferences.introSeen, ready]);

  const closeIntro = () => {
    setIntroVisible(false);
    updateData((current) => ({
      ...current,
      preferences: { ...current.preferences, introSeen: true },
    }));
  };

  const storedBytes = data.files.reduce((sum, file) => sum + (file.uri ? file.sizeBytes : 0), 0);
  const recentActivity = [...data.activity].sort((a, b) => b.createdAt - a.createdAt).slice(0, 3);

  return (
    <Screen>
      <View style={styles.brandRow}>
        <View style={styles.brandLockup}>
          <Image source={require('../../assets/images/icon.png')} style={styles.brandIcon} />
          <View>
            <AppText weight="bold" style={[styles.brandName, { color: colors.foreground }]}>
              KHMER GAME PORT
            </AppText>
            <AppText style={[styles.brandCredit, { color: colors.mutedForeground }]}>
              {labels.projectBy}
            </AppText>
          </View>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Open settings"
          onPress={() => router.navigate('/settings')}
          style={[styles.profileButton, { backgroundColor: colors.secondary, borderColor: colors.border }]}
        >
          <Ionicons name="person-outline" size={19} color={colors.primary} />
        </Pressable>
      </View>

      <View style={styles.statusStrip}>
        <View style={styles.statusLeft}>
          <View style={styles.liveDot} />
          <AppText weight="bold" style={{ color: '#D8F7E3', fontSize: 10, letterSpacing: 1.1 }}>SYSTEM READY</AppText>
        </View>
        <AppText style={{ color: '#A9A39A', fontSize: 10, letterSpacing: 1 }}>QII GAMING EXPERIENCE</AppText>
      </View>

      <ImageBackground
        source={require('../../assets/images/temple-night.jpg')}
        imageStyle={styles.templeImage}
        style={styles.heroBanner}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(5,7,12,0.12)', 'rgba(5,7,12,0.48)', 'rgba(5,7,12,0.94)']}
          locations={[0, 0.52, 1]}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.heroContent}>
          <View style={styles.heroCopy}>
            <Tag label="KHMER • IOS COMPANION" tone="accent" />
            <AppText weight="bold" style={styles.heroTitle}>Play what iOS can run.</AppText>
            <AppText style={styles.heroSubtitle}>
              Organize your game profiles and files. Unsupported engines stay clearly marked.
            </AppText>
            <ActionButton
              label={labels.library}
              icon="game-controller-outline"
              onPress={() => router.navigate('/games')}
              testID="hub-open-library"
            />
          </View>
          <View style={styles.heroBadge}>
            <Ionicons name="sparkles" size={25} color="#FFC83D" />
            <AppText weight="bold" style={{ color: '#FFE4A0', fontSize: 11, letterSpacing: 1 }}>KHMER GAME PORT</AppText>
          </View>
        </View>
      </ImageBackground>

      <View style={styles.metricsRow}>
        <Panel style={styles.metricCard}>
          <View style={[styles.metricIcon, { backgroundColor: '#267BEA33' }]}>
            <Ionicons name="folder" size={25} color="#55A8FF" />
          </View>
          <View style={styles.metricText}>
            <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{labels.library}</AppText>
            <AppText weight="bold" style={{ color: colors.foreground, fontSize: 25 }}>{data.games.length}</AppText>
            <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>local profiles</AppText>
          </View>
          <Ionicons name="chevron-forward-circle" size={24} color={colors.mutedForeground} />
        </Panel>
        <Panel style={styles.metricCard}>
          <View style={[styles.metricIcon, { backgroundColor: '#27C97933' }]}>
            <Ionicons name="layers" size={25} color="#39DB8A" />
          </View>
          <View style={styles.metricText}>
            <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{labels.localStorage}</AppText>
            <AppText weight="bold" style={{ color: colors.foreground, fontSize: 25 }}>{formatBytes(storedBytes)}</AppText>
            <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>tracked app files</AppText>
          </View>
          <Ionicons name="chevron-forward-circle" size={24} color={colors.mutedForeground} />
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <View style={styles.quickHeading}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
            <Ionicons name="flash" size={22} color="#FFC328" />
            <SectionTitle title={labels.quickAccess} />
          </View>
          <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>4 shortcuts</AppText>
        </View>
        <View style={styles.quickGrid}>
          <QuickLink
            icon="game-controller"
            title="My Games"
            detail={`${data.games.length} local profiles`}
            onPress={() => router.navigate('/games')}
          />
          <QuickLink
            icon="folder-open"
            title={labels.files}
            detail={`${data.files.length} tracked files`}
            onPress={() => router.navigate('/files')}
          />
          <QuickLink
            icon="download"
            title={labels.downloads}
            detail={`${data.downloads.length} records`}
            onPress={() => router.navigate('/tools')}
          />
          <QuickLink
            icon="settings"
            title="Settings"
            detail="App settings & preferences"
            onPress={() => router.navigate('/settings')}
          />
        </View>
      </View>

      <Panel style={{ gap: 14 }}>
        <View style={styles.engineHeader}>
          <View style={[styles.engineIcon, { backgroundColor: `${colors.primary}20` }]}>
            <Ionicons name="hardware-chip-outline" size={19} color={colors.primary} />
          </View>
          <View style={{ flex: 1, gap: 3 }}>
            <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
              Game engine
            </AppText>
            <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>
              No compatible native runtime is installed
            </AppText>
          </View>
          <Tag label={labels.notInstalled} />
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18 }}>
          PC game files and IPA packages can be stored for inspection, but this app cannot install them or run PC versions of games on iOS.
        </AppText>
      </Panel>

      <View style={{ gap: 12 }}>
        <SectionTitle title={labels.recentActivity} action={labels.more} onAction={() => router.navigate('/tools')} />
        {recentActivity.length === 0 ? (
          <Panel style={{ paddingVertical: 18 }}>
            <AppText style={{ color: colors.mutedForeground, fontSize: 12, textAlign: 'center' }}>
              Your real activity will appear here as you add profiles, files, and downloads.
            </AppText>
          </Panel>
        ) : (
          <Panel style={{ gap: 15 }}>
            {recentActivity.map((item) => (
              <View key={item.id} style={styles.activityRow}>
                <View style={[styles.activityDot, { backgroundColor: colors.primary }]} />
                <AppText numberOfLines={1} style={{ color: colors.foreground, flex: 1, fontSize: 12 }}>
                  {item.label}
                </AppText>
                <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                  {new Date(item.createdAt).toLocaleDateString()}
                </AppText>
              </View>
            ))}
          </Panel>
        )}
      </View>

      <Modal visible={introVisible} animationType="fade" onRequestClose={closeIntro}>
        <ImageBackground
          source={require('../../assets/images/temple-night.jpg')}
          style={styles.introBackground}
          resizeMode="cover"
        >
          <LinearGradient
            colors={['rgba(11,11,10,0.12)', 'rgba(11,11,10,0.91)', 'rgba(11,11,10,1)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.introContent}>
            <Image source={require('../../assets/images/icon.png')} style={styles.introIcon} />
            <AppText style={{ color: colors.primary, fontSize: 12, letterSpacing: 2 }}>
              PROJECT BY QII QII
            </AppText>
            <AppText weight="bold" style={[styles.introTitle, { color: colors.foreground }]}>KHMER GAME PORT</AppText>
            <AppText style={[styles.introSubtitle, { color: colors.secondaryForeground }]}>
              {ready ? 'Your local library is ready.' : 'Preparing local preferences…'}
            </AppText>
            <ActionButton label="Enter hub" icon="arrow-forward" onPress={closeIntro} />
            <Pressable accessibilityRole="button" onPress={closeIntro} style={{ padding: 12 }}>
              <AppText style={{ color: colors.secondaryForeground, fontSize: 12 }}>Skip intro</AppText>
            </Pressable>
          </View>
        </ImageBackground>
      </Modal>
    </Screen>
  );
}

function QuickLink({
  icon,
  title,
  detail,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  detail: string;
  onPress: () => void;
}) {
  const colors = useAppColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${title}, ${detail}`}
      onPress={onPress}
      style={({ pressed }) => [styles.quickLinkPressable, pressed && { opacity: 0.78, transform: [{ scale: 0.98 }] }]}
    >
      <Panel style={styles.quickCard}>
        <View style={[styles.quickIconWrap, { backgroundColor: `${colors.primary}18`, borderColor: `${colors.primary}35` }]}>
          <Ionicons name={icon} size={25} color={colors.primary} />
        </View>
        <View style={styles.quickTextWrap}>
          <AppText weight="bold" numberOfLines={2} style={{ color: colors.foreground, fontSize: 12, lineHeight: 17 }}>
            {title}
          </AppText>
          <AppText numberOfLines={1} style={{ color: colors.mutedForeground, fontSize: 11 }}>
            {detail}
          </AppText>
        </View>
        <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
      </Panel>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  brandRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statusStrip: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#151D19', borderColor: '#294334', borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 9 },
  statusLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#58D68D' },
  brandLockup: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandIcon: { width: 38, height: 38, borderRadius: 12 },
  brandName: { fontSize: 12, letterSpacing: 1.5 },
  brandCredit: { fontSize: 10, marginTop: 3 },
  profileButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    borderWidth: 1,
  },
  heroTitle: { color: '#FFFFFF', fontSize: 29, lineHeight: 34, letterSpacing: -0.8 },
  heroSubtitle: { color: '#F0EDE7', fontSize: 12, lineHeight: 18, maxWidth: 430 },
  heroBanner: { minHeight: 205, borderRadius: 23, borderWidth: 1, borderColor: '#765B2D', overflow: 'hidden', padding: 18, justifyContent: 'center' },
  templeImage: { borderRadius: 22 },
  heroContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16 },
  heroCopy: { flex: 1, alignItems: 'flex-start', gap: 9 },
  heroBadge: { alignItems: 'center', justifyContent: 'center', gap: 8, padding: 15, borderRadius: 18, backgroundColor: 'rgba(5,7,12,0.48)', borderWidth: 1, borderColor: '#A9823B', minWidth: 132 },
  metricsRow: { flexDirection: 'row', gap: 12 },
  metricCard: { flex: 1, minHeight: 92, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 13, borderWidth: 1, borderColor: '#4A4337' },
  metricIcon: { width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center' },
  metricText: { flex: 1, gap: 2 },
  quickHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', columnGap: 12, rowGap: 10, alignItems: 'stretch' },
  quickLinkPressable: { width: '48%', minWidth: 190, flexGrow: 1 },
  quickCard: { width: '100%', minHeight: 78, paddingHorizontal: 15, paddingVertical: 11, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: '#5A4930', borderRadius: 17 },
  quickIconWrap: { width: 48, height: 48, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  quickTextWrap: { flex: 1, minWidth: 0, gap: 5 },
  engineHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  engineIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  activityRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  activityDot: { width: 6, height: 6, borderRadius: 3 },
  introBackground: { flex: 1, justifyContent: 'center' },
  introContent: { alignItems: 'center', gap: 14, padding: 28 },
  introIcon: { width: 98, height: 98, borderRadius: 28, marginBottom: 8 },
  introTitle: { fontSize: 27, letterSpacing: 2, textAlign: 'center' },
  introSubtitle: { fontSize: 14, marginBottom: 10 },
});
