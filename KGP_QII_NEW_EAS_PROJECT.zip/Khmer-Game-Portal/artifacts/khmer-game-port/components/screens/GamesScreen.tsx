import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  StyleSheet,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AppText, ActionButton, EmptyState, FormField, IconButton, Panel, Screen, SearchField, SectionTitle, Sheet, Tag } from '@/components/ui';
import { useAppState } from '@/src/state';
import { useAppColors } from '@/src/theme';
import { useLabels } from '@/src/i18n';
import { makeId, type Compatibility, type GameProfile } from '@/src/models';
import { getGTAEngineStatus, launchGTA, type GTAEngineStatus } from '@/modules/gta-engine/src';

export default function GamesScreen() {
  const colors = useAppColors();
  const labels = useLabels();
  const { data, updateData, logActivity } = useAppState();
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [editing, setEditing] = useState<GameProfile | null>(null);
  const [name, setName] = useState('');
  const [version, setVersion] = useState('');
  const [description, setDescription] = useState('');
  const [compatibility, setCompatibility] = useState<Compatibility>('unknown');
  const [engineStatus, setEngineStatus] = useState<GTAEngineStatus | null>(null);
  const [checkingEngine, setCheckingEngine] = useState(false);

  const refreshEngineStatus = async () => {
    setCheckingEngine(true);
    try { setEngineStatus(await getGTAEngineStatus()); }
    catch { setEngineStatus(null); }
    finally { setCheckingEngine(false); }
  };

  useEffect(() => { void refreshEngineStatus(); }, []);

  const games = useMemo(
    () =>
      [...data.games]
        .filter((game) => `${game.name} ${game.description}`.toLowerCase().includes(search.toLowerCase()))
        .sort((a, b) => Number(b.favorite) - Number(a.favorite) || b.createdAt - a.createdAt),
    [data.games, search],
  );

  const openAdd = () => {
    setEditing(null);
    setName('');
    setVersion('');
    setDescription('');
    setCompatibility('unknown');
    setShowAdd(true);
  };

  const openEdit = (game: GameProfile) => {
    setEditing(game);
    setName(game.name);
    setVersion(game.version);
    setDescription(game.description);
    setCompatibility(game.compatibility);
    setShowAdd(true);
  };

  const saveGame = () => {
    const cleanName = name.trim();
    if (!cleanName) {
      Alert.alert('Game name required', 'Enter a name before saving this profile.');
      return;
    }
    if (editing) {
      updateData((current) => ({
        ...current,
        games: current.games.map((game) =>
          game.id === editing.id
            ? { ...game, name: cleanName, version: version.trim(), description: description.trim(), compatibility }
            : game,
        ),
      }));
      logActivity(`Updated game profile: ${cleanName}`, 'game');
    } else {
      const profile: GameProfile = {
        id: makeId('game'),
        name: cleanName,
        version: version.trim(),
        description: description.trim(),
        compatibility,
        favorite: false,
        createdAt: Date.now(),
      };
      updateData((current) => ({ ...current, games: [profile, ...current.games] }));
      logActivity(`Added game profile: ${cleanName}`, 'game');
    }
    setShowAdd(false);
  };

  const toggleFavorite = (gameId: string) => {
    updateData((current) => ({
      ...current,
      games: current.games.map((game) =>
        game.id === gameId ? { ...game, favorite: !game.favorite } : game,
      ),
    }));
  };

  const removeGame = (game: GameProfile) => {
    Alert.alert('Remove game profile?', `${game.name} will be removed from your local library.`, [
      { text: 'Keep', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          updateData((current) => ({
            ...current,
            games: current.games.filter((entry) => entry.id !== game.id),
          }));
          logActivity(`Removed game profile: ${game.name}`, 'game');
        },
      },
    ]);
  };

  const launchUnavailable = (game: GameProfile) => {
    Alert.alert(
      'No compatible runtime',
      `${game.name} is a library profile only. The GTA V native engine is not linked in this KGP QII build yet.`,
    );
  };

  const launchGtaMode = async (mode: 'story' | 'sandbox') => {
    try {
      const result = await launchGTA(mode);
      if (result.started) {
        Alert.alert('GTA V', 'The native engine accepted the launch request.');
      } else {
        Alert.alert('GTA V engine not ready', result.reason ?? 'The native runtime is not available.');
      }
      await refreshEngineStatus();
    } catch (error) {
      Alert.alert('GTA V launch error', error instanceof Error ? error.message : 'Unknown native bridge error.');
    }
  };

  return (
    <Screen>
      <View style={styles.pageHeader}>
        <View style={{ flex: 1, gap: 5 }}>
          <AppText style={{ color: colors.primary, fontSize: 11, letterSpacing: 1.5 }}>LIBRARY</AppText>
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 29 }}>{labels.games}</AppText>
        </View>
        <IconButton icon="add" label={labels.addGame} onPress={openAdd} testID="games-add-profile" />
      </View>
      <SearchField value={search} onChangeText={setSearch} placeholder={labels.searchGames} testID="games-search" />

      <Panel style={styles.notice}>
        <Ionicons name="information-circle-outline" size={19} color={colors.primary} />
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17, flex: 1 }}>
          Profiles organize your own game metadata. Launching requires a separately installed, compatible iOS runtime.
        </AppText>
      </Panel>

      <Panel style={{ gap: 12, borderColor: `${colors.primary}70`, borderWidth: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
          <Ionicons name="car-sport-outline" size={21} color={colors.primary} />
          <View style={{ flex: 1, gap: 2 }}>
            <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>GTA V · Native Integration</AppText>
            <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>KGP native bridge status</AppText>
          </View>
          <Tag label={engineStatus?.engineLinked ? 'ENGINE LINKED' : 'BRIDGE ONLY'} tone={engineStatus?.engineLinked ? 'success' : 'accent'} />
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          {engineStatus?.message ?? 'Checking native bridge status…'}
        </AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>
          <Tag label={engineStatus?.upstreamSourceBundled ? 'UPSTREAM SOURCE INCLUDED' : 'SOURCE MISSING'} />
          <Tag label={engineStatus?.engineBuildInputsPresent ? 'BUILD INPUTS READY' : 'BUILD INPUTS MISSING'} />
          <Tag label={engineStatus?.wasmArm64RuntimeLinked ? 'WASM / ARM64 READY' : 'WASM / ARM64 PENDING'} />
          <Tag label={engineStatus?.metalRendererLinked ? 'METAL READY' : 'METAL PENDING'} />
          <Tag label={engineStatus?.gameFilesReady ? 'GAME FILES READY' : 'GAME FILES PENDING'} />
        </View>
        <View style={{ flexDirection: 'row', gap: 9 }}>
          <View style={{ flex: 1 }}>
            <ActionButton label="Story Mode" icon="play" secondary disabled={!engineStatus?.storyModeAvailable} onPress={() => void launchGtaMode('story')} />
          </View>
          <View style={{ flex: 1 }}>
            <ActionButton label="Sandbox" icon="construct-outline" secondary disabled={!engineStatus?.sandboxAvailable} onPress={() => void launchGtaMode('sandbox')} />
          </View>
        </View>
        <ActionButton label={checkingEngine ? 'Checking native bridge…' : 'Check engine status'} icon="refresh-outline" secondary loading={checkingEngine} onPress={() => void refreshEngineStatus()} />
        <AppText style={{ color: colors.mutedForeground, fontSize: 10, lineHeight: 15 }}>
          The complete upstream source is included in this project, but its repository builds a separate iOS app. The generated WASM engine and WABT toolchain are not in the supplied archive, and the engine is not yet linked into KGP QII. Gameplay cannot start from this screen yet.
        </AppText>
      </Panel>

      {games.length === 0 ? (
        <Panel>
          <EmptyState
            icon="game-controller-outline"
            title={search ? 'No matching games' : labels.noGames}
            detail={search ? 'Try a different name or clear the search.' : 'Add a profile to track compatibility, favorites, and notes on this device.'}
          />
          {!search ? <ActionButton label={labels.addGame} icon="add" onPress={openAdd} /> : null}
        </Panel>
      ) : (
        <View style={{ gap: 12 }}>
          {games.map((game) => (
            <Panel key={game.id} style={styles.gameCard}>
              <View style={styles.gameTop}>
                <View style={[styles.gameArt, { backgroundColor: `${colors.primary}1C` }]}>
                  <Ionicons name="game-controller-outline" size={23} color={colors.primary} />
                </View>
                <View style={{ flex: 1, gap: 5 }}>
                  <AppText weight="bold" numberOfLines={1} style={{ color: colors.foreground, fontSize: 15 }}>
                    {game.name}
                  </AppText>
                  <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>
                    {game.version || 'Version not specified'}
                  </AppText>
                </View>
                <IconButton
                  icon={game.favorite ? 'heart' : 'heart-outline'}
                  label={game.favorite ? 'Remove favorite' : 'Add favorite'}
                  color={game.favorite ? colors.primary : colors.mutedForeground}
                  onPress={() => toggleFavorite(game.id)}
                />
              </View>
              {game.description ? (
                <AppText style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18 }}>
                  {game.description}
                </AppText>
              ) : null}
              <View style={styles.gameFooter}>
                <Tag
                  label={compatibilityLabel(game.compatibility)}
                  tone={game.compatibility === 'incompatible' ? 'danger' : game.compatibility === 'partial' ? 'accent' : 'neutral'}
                />
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}>
                  <IconButton icon="create-outline" label="Edit profile" onPress={() => openEdit(game)} />
                  <IconButton icon="trash-outline" label="Delete profile" color={colors.destructive} onPress={() => removeGame(game)} />
                </View>
              </View>
              <ActionButton
                label="Launch unavailable"
                icon="play"
                secondary
                onPress={() => launchUnavailable(game)}
              />
            </Panel>
          ))}
        </View>
      )}

      <View style={{ gap: 12 }}>
        <SectionTitle title="Compatibility note" />
        <Panel style={{ gap: 8 }}>
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 13 }}>
            GTA V · PC edition
          </AppText>
          <AppText style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18 }}>
            The Windows PC build cannot run directly on iOS. This app does not include GTA V files, an authorized port, or a compatible runtime.
          </AppText>
          <Tag label="Incompatible on this build" tone="danger" />
        </Panel>
      </View>

      <Sheet
        visible={showAdd}
        title={editing ? 'Edit game profile' : labels.addGame}
        onClose={() => setShowAdd(false)}
      >
        <FormField label="Game name" value={name} onChangeText={setName} placeholder="Enter a game name" />
        <FormField label="Version (optional)" value={version} onChangeText={setVersion} placeholder="For example, 1.0" />
        <FormField label="Notes (optional)" value={description} onChangeText={setDescription} placeholder="Compatibility notes or source" multiline />
        <AppText weight="medium" style={{ color: colors.mutedForeground, fontSize: 12 }}>
          Compatibility
        </AppText>
        <View style={styles.choiceRow}>
          {([
            ['unknown', 'Unknown'],
            ['partial', 'Partial'],
            ['incompatible', 'Incompatible'],
          ] as const).map(([value, label]) => (
            <Pressable
              key={value}
              onPress={() => setCompatibility(value)}
              style={[
                styles.choice,
                {
                  backgroundColor: compatibility === value ? `${colors.primary}20` : colors.background,
                  borderColor: compatibility === value ? colors.primary : colors.border,
                },
              ]}
            >
              <AppText style={{ color: compatibility === value ? colors.primary : colors.mutedForeground, fontSize: 11 }}>
                {label}
              </AppText>
            </Pressable>
          ))}
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          This is your saved assessment, not an automated engine test.
        </AppText>
        <ActionButton label={editing ? 'Save changes' : 'Create profile'} icon="checkmark" onPress={saveGame} testID="games-save-profile" />
      </Sheet>
    </Screen>
  );
}

function compatibilityLabel(value: Compatibility): string {
  if (value === 'incompatible') return 'Incompatible';
  if (value === 'partial') return 'Partially compatible';
  return 'Not tested';
}

const styles = StyleSheet.create({
  pageHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  notice: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12 },
  gameCard: { gap: 14 },
  gameTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  gameArt: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  gameFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  choiceRow: { flexDirection: 'row', gap: 8 },
  choice: { flex: 1, alignItems: 'center', borderWidth: 1, borderRadius: 12, paddingVertical: 10 },
});
