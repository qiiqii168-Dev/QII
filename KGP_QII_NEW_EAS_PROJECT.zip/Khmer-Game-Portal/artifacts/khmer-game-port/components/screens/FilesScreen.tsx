import React, { useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  StyleSheet,
  View,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { deleteAsync } from 'expo-file-system/legacy';
import { Ionicons } from '@expo/vector-icons';
import { ActionButton, AppText, EmptyState, IconButton, Panel, Screen, SearchField, SectionTitle, Tag } from '@/components/ui';
import { useAppState } from '@/src/state';
import { useAppColors } from '@/src/theme';
import { useLabels } from '@/src/i18n';
import {
  copyToAppStorage,
  formatBytes,
  getExtension,
  inspectAndExtractZip,
} from '@/src/file-service';
import { makeId } from '@/src/models';

export default function FilesScreen() {
  const colors = useAppColors();
  const labels = useLabels();
  const { data, updateData, logActivity } = useAppState();
  const [search, setSearch] = useState('');
  const [busy, setBusy] = useState(false);
  const [sortBy, setSortBy] = useState<'recent' | 'name' | 'size'>('recent');

  const files = useMemo(
    () =>
      [...data.files]
        .filter((file) => `${file.name} ${file.extension}`.toLowerCase().includes(search.toLowerCase()))
        .sort((a, b) =>
          sortBy === 'name'
            ? a.name.localeCompare(b.name)
            : sortBy === 'size'
              ? b.sizeBytes - a.sizeBytes
              : b.importedAt - a.importedAt,
        ),
    [data.files, search, sortBy],
  );

  const importFiles = async () => {
    setBusy(true);
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        multiple: true,
        copyToCacheDirectory: true,
      });
      if (result.canceled) return;
      let added = 0;
      for (const asset of result.assets) {
        const copied = await copyToAppStorage(asset.uri, asset.name);
        updateData((current) => ({
          ...current,
          files: [
            {
              id: makeId('file'),
              name: copied.name,
              uri: copied.uri,
              sizeBytes: copied.sizeBytes,
              extension: getExtension(copied.name),
              importedAt: Date.now(),
              source: 'import',
            },
            ...current.files,
          ],
        }));
        logActivity(`Imported file: ${copied.name}`, 'file');
        added += 1;
      }
      if (added) Alert.alert('Import complete', `${added} file${added === 1 ? '' : 's'} copied into app storage.`);
    } catch (error) {
      Alert.alert('Import failed', error instanceof Error ? error.message : 'The selected files could not be imported.');
    } finally {
      setBusy(false);
    }
  };

  const removeFile = (fileId: string) => {
    const file = data.files.find((entry) => entry.id === fileId);
    if (!file) return;
    Alert.alert('Delete local file?', `${file.name} will be removed from this app’s storage.`, [
      { text: 'Keep', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            if (file.uri) await deleteAsync(file.uri, { idempotent: true });
            updateData((current) => ({
              ...current,
              files: current.files.filter((entry) => entry.id !== fileId),
            }));
            logActivity(`Deleted file: ${file.name}`, 'file');
          } catch {
            Alert.alert('Delete failed', 'This file could not be removed from app storage.');
          }
        },
      },
    ]);
  };

  const extract = (fileId: string) => {
    const archive = data.files.find((entry) => entry.id === fileId);
    if (!archive) return;
    if (archive.extension !== 'zip') {
      Alert.alert('Inspection only', 'RAR and 7Z files can be stored, but extraction needs an iOS-compatible archive engine that is not included.');
      return;
    }
    Alert.alert(
      'Extract this ZIP?',
      'ZIP files are checked for unsafe paths and limited to 25 MB compressed, 64 MB expanded, and 300 entries.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Extract',
          onPress: async () => {
            setBusy(true);
            try {
              const extracted = await inspectAndExtractZip(archive.uri);
              updateData((current) => ({ ...current, files: [...extracted, ...current.files] }));
              logActivity(`Extracted ZIP: ${archive.name}`, 'file');
              Alert.alert('Extraction complete', `${extracted.length} safe file${extracted.length === 1 ? '' : 's'} extracted.`);
            } catch (error) {
              Alert.alert('ZIP not extracted', error instanceof Error ? error.message : 'The archive could not be safely extracted.');
            } finally {
              setBusy(false);
            }
          },
        },
      ],
    );
  };

  const inspect = (fileId: string) => {
    const file = data.files.find((entry) => entry.id === fileId);
    if (!file) return;
    const message =
      file.extension === 'ipa'
        ? 'Stored for reference only. iOS does not let this app install or execute another IPA package.'
        : file.extension === 'zip'
          ? 'ZIP archives can be safely extracted within the listed size and path limits.'
          : 'This archive can be stored and catalogued. RAR/7Z extraction is not available in this build.';
    Alert.alert(`${file.name}`, `${formatBytes(file.sizeBytes)} • ${new Date(file.importedAt).toLocaleString()}\n\n${message}`);
  };

  const storedBytes = data.files.reduce((sum, file) => sum + (file.uri ? file.sizeBytes : 0), 0);

  return (
    <Screen>
      <View style={styles.pageHeader}>
        <View style={{ flex: 1, gap: 5 }}>
          <AppText style={{ color: colors.primary, fontSize: 11, letterSpacing: 1.5 }}>PRIVATE APP SPACE</AppText>
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 29 }}>{labels.files}</AppText>
        </View>
        <IconButton icon="add" label={labels.importFiles} onPress={importFiles} testID="files-import" />
      </View>

      <Panel style={styles.storageSummary}>
        <View style={[styles.summaryIcon, { backgroundColor: `${colors.primary}1D` }]}>
          <Ionicons name="server-outline" size={20} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 15 }}>
            {formatBytes(storedBytes)}
          </AppText>
          <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>
            Tracked in KHMER GAME PORT only
          </AppText>
        </View>
        <Tag label={`${data.files.length} FILES`} />
      </Panel>

      <SearchField value={search} onChangeText={setSearch} placeholder="Search file names" testID="files-search" />
      <View style={styles.formats}>
        {['ZIP', 'RAR', '7Z', 'IPA'].map((extension) => (
          <Tag key={extension} label={extension} tone="accent" />
        ))}
      </View>
      <View style={styles.sortRow}>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>Sort</AppText>
        {([
          ['recent', 'Recent'],
          ['name', 'Name'],
          ['size', 'Size'],
        ] as const).map(([key, label]) => (
          <Pressable
            key={key}
            onPress={() => setSortBy(key)}
            style={[
              styles.sortChoice,
              {
                borderColor: sortBy === key ? colors.primary : colors.border,
                backgroundColor: sortBy === key ? `${colors.primary}16` : colors.card,
              },
            ]}
          >
            <AppText style={{ color: sortBy === key ? colors.primary : colors.mutedForeground, fontSize: 10 }}>
              {label}
            </AppText>
          </Pressable>
        ))}
      </View>
      <Panel style={{ gap: 6 }}>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          Files are copied only after you select them in Apple’s Files picker. The app cannot scan the rest of your iPhone.
        </AppText>
      </Panel>
      <ActionButton label={busy ? 'Working…' : labels.importFiles} icon="folder-open-outline" onPress={importFiles} loading={busy} testID="files-import-button" />

      <View style={{ gap: 12 }}>
        <SectionTitle title="Your files" />
        {files.length === 0 ? (
          <Panel>
            <EmptyState icon="archive-outline" title={search ? 'No matching files' : labels.noFiles} detail="Choose documents, images, audio, video, archives, or game files from Apple Files to add them to this app’s private storage." />
          </Panel>
        ) : (
          <View style={{ gap: 10 }}>
            {files.map((file) => (
              <Panel key={file.id} style={styles.fileRow}>
                <View style={[styles.fileTypeIcon, { backgroundColor: `${colors.primary}1C` }]}>
                  <AppText weight="bold" style={{ color: colors.primary, fontSize: 9 }}>{file.extension.toUpperCase()}</AppText>
                </View>
                <View style={{ flex: 1, gap: 4 }}>
                  <AppText weight="medium" numberOfLines={1} style={{ color: colors.foreground, fontSize: 12 }}>
                    {file.name}
                  </AppText>
                  <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                    {file.uri ? formatBytes(file.sizeBytes) : 'Metadata only · file not on this device'} · {file.source} · {new Date(file.importedAt).toLocaleDateString()}
                  </AppText>
                </View>
                <View style={{ alignItems: 'center', gap: 3 }}>
                  <IconButton icon="eye-outline" label={`Inspect ${file.name}`} onPress={() => inspect(file.id)} />
                  {file.extension === 'zip' ? (
                    <IconButton icon="expand-outline" label={`Extract ${file.name}`} color={colors.primary} onPress={() => extract(file.id)} />
                  ) : null}
                  <IconButton icon="trash-outline" label={`Delete ${file.name}`} color={colors.destructive} onPress={() => removeFile(file.id)} />
                </View>
              </Panel>
            ))}
          </View>
        )}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  pageHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  storageSummary: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  summaryIcon: { width: 42, height: 42, alignItems: 'center', justifyContent: 'center', borderRadius: 14 },
  formats: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  sortRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  sortChoice: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7 },
  fileRow: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 13 },
  fileTypeIcon: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
});
