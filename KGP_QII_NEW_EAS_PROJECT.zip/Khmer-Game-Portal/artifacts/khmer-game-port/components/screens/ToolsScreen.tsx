import React, { useMemo, useState } from 'react';
import {
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import {
  cacheDirectory,
  deleteAsync,
  EncodingType,
  getFreeDiskStorageAsync,
  getTotalDiskCapacityAsync,
  readAsStringAsync,
  writeAsStringAsync,
} from 'expo-file-system/legacy';
import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import * as Sharing from 'expo-sharing';
import * as Device from 'expo-device';
import * as Application from 'expo-application';
import { Ionicons } from '@expo/vector-icons';
import {
  ActionButton,
  AppText,
  EmptyState,
  FormField,
  IconButton,
  Panel,
  Screen,
  SearchField,
  SectionTitle,
  Sheet,
  Tag,
} from '@/components/ui';
import { useAppState } from '@/src/state';
import { useAppColors } from '@/src/theme';
import { localize, useLabels } from '@/src/i18n';
import {
  copyToAppStorage,
  formatBytes,
} from '@/src/file-service';
import { CONTROL_ICONS } from '@/src/control-assets';
import {
  defaultControls,
  makeId,
  type ControlPreset,
  type ModCategory,
  type ModRecord,
  type VaultFile,
} from '@/src/models';

type ToolSection = 'downloads' | 'graphics' | 'mods' | 'controls' | 'radio' | 'more';

export default function ToolsScreen() {
  const colors = useAppColors();
  const labels = useLabels();
  const { data, updateData, logActivity, startDownload, pauseDownload, resumeDownload, cancelDownload } = useAppState();
  const [section, setSection] = useState<ToolSection>('downloads');

  return (
    <Screen>
      <View style={styles.pageHeader}>
        <View style={{ flex: 1, gap: 5 }}>
          <AppText style={{ color: colors.primary, fontSize: 11, letterSpacing: 1.5 }}>
            {localize(data.preferences.language, 'LOCAL TOOLKIT', 'ឧបករណ៍ក្នុងកម្មវិធី')}
          </AppText>
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 29 }}>{labels.tools}</AppText>
        </View>
        <View style={[styles.toolCounter, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
          <Ionicons name="layers-outline" size={16} color={colors.primary} />
          <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
            {localize(data.preferences.language, '6 sections', '៦ ផ្នែក')}
          </AppText>
        </View>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={[styles.segmentScroller, { backgroundColor: colors.card, borderColor: colors.border }]}
        contentContainerStyle={styles.segmentRow}
      >
        {([
          ['downloads', labels.downloads, 'download-outline'],
          ['graphics', labels.graphics, 'color-palette-outline'],
          ['mods', labels.mods, 'extension-puzzle-outline'],
          ['controls', labels.controls, 'game-controller-outline'],
          ['radio', labels.radio, 'radio-outline'],
          ['more', labels.more, 'ellipsis-horizontal'],
        ] as const).map(([key, label, icon]) => (
          <Pressable
            key={key}
            accessibilityRole="button"
            onPress={() => setSection(key)}
            style={[
              styles.segment,
              section === key && { backgroundColor: `${colors.primary}20` },
            ]}
          >
            <Ionicons name={icon} size={16} color={section === key ? colors.primary : colors.mutedForeground} />
            <AppText
              weight={section === key ? 'bold' : 'regular'}
              style={{ color: section === key ? colors.primary : colors.mutedForeground, fontSize: 10 }}
            >
              {label}
            </AppText>
          </Pressable>
        ))}
      </ScrollView>

      {section === 'downloads' ? (
        <DownloadsTool />
      ) : section === 'graphics' ? (
        <GraphicsTool />
      ) : section === 'mods' ? (
        <ModsTool />
      ) : section === 'controls' ? (
        <ControlsTool />
      ) : section === 'radio' ? (
        <RadioTool />
      ) : (
        <MoreTools />
      )}

      {data.activity.length > 0 && section !== 'more' ? (
        <Panel style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
          <Ionicons name="time-outline" size={17} color={colors.primary} />
          <AppText numberOfLines={1} style={{ color: colors.mutedForeground, fontSize: 11, flex: 1 }}>
            Latest activity · {data.activity[data.activity.length - 1]?.label}
          </AppText>
        </Panel>
      ) : null}
    </Screen>
  );
}

function DownloadsTool() {
  const colors = useAppColors();
  const { data, startDownload, pauseDownload, resumeDownload, cancelDownload } = useAppState();
  const language = data.preferences.language;
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const statusLabel = (status: string) => {
    const labels: Record<string, [string, string]> = {
      queued: ['Queued', 'កំពុងរង់ចាំ'],
      downloading: ['Downloading', 'កំពុងទាញយក'],
      paused: ['Paused', 'បានផ្អាក'],
      completed: ['Completed', 'បានបញ្ចប់'],
      failed: ['Failed', 'បរាជ័យ'],
      cancelled: ['Cancelled', 'បានបោះបង់'],
    };
    const pair = labels[status] ?? [status, status];
    return localize(language, pair[0], pair[1]);
  };

  const submit = async () => {
    if (!url.trim()) {
      Alert.alert(
        localize(language, 'Download link required', 'ត្រូវការតំណទាញយក'),
        localize(language, 'Paste a direct HTTPS link to a file you are authorized to download.', 'បញ្ចូលតំណ HTTPS ផ្ទាល់ទៅឯកសារដែលអ្នកមានសិទ្ធិទាញយក។'),
      );
      return;
    }
    setBusy(true);
    try {
      await startDownload(url);
      setUrl('');
    } catch (error) {
      Alert.alert(localize(language, 'Download not started', 'មិនអាចចាប់ផ្ដើមទាញយក'), error instanceof Error ? error.message : localize(language, 'The link could not be downloaded.', 'មិនអាចទាញយកតាមតំណនេះទេ។'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ gap: 14 }}>
      <Panel style={{ gap: 11 }}>
        <View style={styles.toolTitle}>
          <Ionicons name="cloud-download-outline" size={19} color={colors.primary} />
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
            {localize(language, 'Direct HTTPS download', 'ទាញយក HTTPS ផ្ទាល់')}
          </AppText>
        </View>
        <FormField
          label={localize(language, 'Direct file URL', 'តំណឯកសារផ្ទាល់')}
          value={url}
          onChangeText={setUrl}
          placeholder="https://example.com/archive.zip"
          keyboardType="url"
          autoCapitalize="none"
        />
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          {localize(language, 'The app checks file size and HTTP Range metadata with a metadata-only HEAD request when the host allows it. Downloads use iOS resumable tasks while the app is active; resume depends on server support and a saved iOS checkpoint. No app-defined file-size cap; free iPhone storage and iOS limits still apply.', 'App ពិនិត្យទំហំ File និង HTTP Range ប្រសិនបើ Server អនុញ្ញាត។ Resume អាស្រ័យលើ Server និង Checkpoint របស់ iOS។ មិនកំណត់ទំហំក្នុង App ទេ ប៉ុន្តែអាស្រ័យលើ Storage និង iOS។')}
        </AppText>
        <ActionButton label={localize(language, 'Start download', 'ចាប់ផ្ដើមទាញយក')} icon="download-outline" onPress={submit} loading={busy} testID="download-start" />
      </Panel>

      <View style={{ gap: 12 }}>
        <SectionTitle title={`${localize(language, 'Queue', 'ជួររង់ចាំ')} · ${data.downloads.length}`} />
        {data.downloads.length === 0 ? (
          <Panel>
            <EmptyState
              icon="cloud-download-outline"
              title={localize(language, 'No downloads yet', 'មិនទាន់មានការទាញយកទេ')}
              detail={localize(language, 'Add a direct link to a file you are allowed to download.', 'បន្ថែមតំណផ្ទាល់ទៅឯកសារដែលអ្នកមានសិទ្ធិទាញយក។')}
            />
          </Panel>
        ) : (
          <View style={{ gap: 10 }}>
            {[...data.downloads].map((download) => {
              const ratio =
                download.totalBytes > 0
                  ? Math.min(100, (download.transferredBytes / download.totalBytes) * 100)
                  : 0;
              return (
                <Panel key={download.id} style={{ gap: 11 }}>
                  <View style={styles.downloadHeader}>
                    <View style={{ flex: 1, gap: 5 }}>
                      <AppText weight="medium" numberOfLines={1} style={{ color: colors.foreground, fontSize: 12 }}>
                        {download.fileName}
                      </AppText>
                      <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                        {statusLabel(download.status)} · {download.totalBytes > 0
                          ? `${formatBytes(download.transferredBytes)} / ${formatBytes(download.totalBytes)}`
                          : formatBytes(download.transferredBytes)}
                      </AppText>
                    </View>
                    <DownloadActions
                      status={download.status}
                      language={language}
                      onPause={() => void pauseDownload(download.id)}
                      onResume={() => void resumeDownload(download.id)}
                      onCancel={() => void cancelDownload(download.id)}
                    />
                  </View>
                  <View style={[styles.progressTrack, { backgroundColor: colors.secondary }]}>
                    <View style={[styles.progressFill, { width: `${ratio}%`, backgroundColor: colors.primary }]} />
                  </View>
                  <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                    {download.totalBytes > 0 ? `${ratio.toFixed(1)}%` : 'Progress: size unknown'}
                    {'  ·  '}{formatBytes(download.speedBytesPerSecond ?? 0)}/s
                    {'  ·  '}{download.etaSeconds != null ? `ETA ${Math.floor(download.etaSeconds / 60)}m ${download.etaSeconds % 60}s` : 'ETA —'}
                  </AppText>
                  <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
                    {download.rangeSupport === 'yes' ? 'HTTP Range advertised' : download.rangeSupport === 'no' ? 'HTTP Range not advertised' : 'HTTP Range unknown'}
                    {'  ·  '}{download.contentType || 'Content type unknown'}
                  </AppText>
                  {download.error ? (
                    <AppText style={{ color: colors.destructive, fontSize: 11 }}>{download.error}</AppText>
                  ) : null}
                </Panel>
              );
            })}
          </View>
        )}
      </View>
    </View>
  );
}

function DownloadActions({
  status,
  language,
  onPause,
  onResume,
  onCancel,
}: {
  status: string;
  language: 'en' | 'km';
  onPause: () => void;
  onResume: () => void;
  onCancel: () => void;
}) {
  const colors = useAppColors();
  if (status === 'downloading') {
    return (
      <View style={{ flexDirection: 'row' }}>
        <IconButton icon="pause" label={localize(language, 'Pause download', 'ផ្អាកការទាញយក')} onPress={onPause} />
        <IconButton icon="close" label={localize(language, 'Cancel download', 'បោះបង់ការទាញយក')} color={colors.destructive} onPress={onCancel} />
      </View>
    );
  }
  if (status === 'paused' || status === 'failed') {
    return (
      <View style={{ flexDirection: 'row' }}>
        <IconButton icon="play" label={localize(language, 'Resume download', 'បន្តការទាញយក')} color={colors.primary} onPress={onResume} />
        <IconButton icon="close" label={localize(language, 'Cancel download', 'បោះបង់ការទាញយក')} color={colors.destructive} onPress={onCancel} />
      </View>
    );
  }
  return null;
}

function GraphicsTool() {
  const colors = useAppColors();
  const { data, updateData, logActivity } = useAppState();
  const language = data.preferences.language;
  const preset = data.preferences.graphicsPreset ?? 'balanced';
  const resolution = data.preferences.resolutionTarget ?? 'native';
  const frameRate = data.preferences.frameRateTarget ?? 60;

  const savePreference = <K extends 'graphicsPreset' | 'resolutionTarget' | 'frameRateTarget',>(
    key: K,
    value: NonNullable<(typeof data.preferences)[K]>,
  ) => {
    updateData((current) => ({
      ...current,
      preferences: { ...current.preferences, [key]: value },
    }));
    logActivity(`Changed graphics preference: ${key}`, 'settings');
  };

  const presetOptions = [
    { key: 'performance' as const, label: localize(language, 'Performance', 'ដំណើរការ') },
    { key: 'balanced' as const, label: localize(language, 'Balanced', 'មានតុល្យភាព') },
    { key: 'quality' as const, label: localize(language, 'Quality', 'គុណភាព') },
  ];
  const resolutionOptions = [
    { key: 'native' as const, label: localize(language, 'Device default', 'លំនាំដើមឧបករណ៍') },
    { key: '720p' as const, label: '720p' },
    { key: '1080p' as const, label: '1080p' },
  ];
  const frameRateOptions = [30, 60, 120] as const;

  return (
    <View style={{ gap: 14 }}>
      <Panel style={{ gap: 13 }}>
        <View style={styles.toolTitle}>
          <Ionicons name="color-palette-outline" size={19} color={colors.primary} />
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
            {localize(language, 'Graphics preferences', 'ចំណូលចិត្តក្រាហ្វិក')}
          </AppText>
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          {localize(
            language,
            'Save a preferred profile for later. This companion app has no GTA V rendering engine, so these values do not change the actual game, resolution, or FPS.',
            'រក្សាទុកការកំណត់សម្រាប់ពេលក្រោយ។ កម្មវិធីនេះមិនមានម៉ាស៊ីន GTA V ទេ ដូច្នេះតម្លៃទាំងនេះមិនប្ដូរក្រាហ្វិក គុណភាពបង្ហាញ ឬ FPS ក្នុងហ្គេមពិតទេ។',
          )}
        </AppText>

        <GraphicsChoiceRow
          title={localize(language, 'Preset', 'ការកំណត់ជាមុន')}
          value={preset}
          options={presetOptions}
          onSelect={(value) => savePreference('graphicsPreset', value)}
        />
        <GraphicsChoiceRow
          title={localize(language, 'Resolution target', 'គោលដៅគុណភាពបង្ហាញ')}
          value={resolution}
          options={resolutionOptions}
          onSelect={(value) => savePreference('resolutionTarget', value)}
        />
        <GraphicsChoiceRow
          title={localize(language, 'FPS target', 'គោលដៅ FPS')}
          value={frameRate}
          options={frameRateOptions.map((value) => ({ key: value, label: `${value} FPS` }))}
          onSelect={(value) => savePreference('frameRateTarget', value)}
        />
        <ActionButton
          label={localize(language, 'Reset graphics preferences', 'កំណត់ក្រាហ្វិកឡើងវិញ')}
          icon="refresh-outline"
          secondary
          onPress={() => {
            updateData((current) => ({
              ...current,
              preferences: {
                ...current.preferences,
                graphicsPreset: 'balanced',
                resolutionTarget: 'native',
                frameRateTarget: 60,
              },
            }));
            logActivity('Reset graphics preferences', 'settings');
          }}
        />
      </Panel>
    </View>
  );
}

function GraphicsChoiceRow<T extends string | number>({
  title,
  value,
  options,
  onSelect,
}: {
  title: string;
  value: T;
  options: { key: T; label: string }[];
  onSelect: (value: T) => void;
}) {
  const colors = useAppColors();
  return (
    <View style={{ gap: 7 }}>
      <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{title}</AppText>
      <View style={styles.choiceRow}>
        {options.map((option) => {
          const selected = option.key === value;
          return (
            <Pressable
              key={String(option.key)}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              onPress={() => onSelect(option.key)}
              style={[
                styles.choiceChip,
                {
                  borderColor: selected ? colors.primary : colors.border,
                  backgroundColor: selected ? `${colors.primary}20` : colors.card,
                },
              ]}
            >
              <AppText style={{ color: selected ? colors.primary : colors.foreground, fontSize: 10, textAlign: 'center' }}>
                {option.label}
              </AppText>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

function ModsTool() {
  const colors = useAppColors();
  const { data, updateData, logActivity } = useAppState();
  const language = data.preferences.language;
  const [showAdd, setShowAdd] = useState(false);
  const [editing, setEditing] = useState<ModRecord | null>(null);
  const [name, setName] = useState('');
  const [gameName, setGameName] = useState('');
  const [notes, setNotes] = useState('');
  const [category, setCategory] = useState<ModCategory>('Other');
  const [filter, setFilter] = useState<ModCategory | 'All'>('All');
  const categories: ModCategory[] = ['Gameplay', 'Graphics', 'Audio', 'UI', 'Other'];
  const visibleMods = data.mods.filter((mod) => filter === 'All' || (mod.category ?? 'Other') === filter);
  const categoryLabel = (item: ModCategory | 'All') => {
    if (item === 'All') return localize(language, 'All', 'ទាំងអស់');
    const khmer: Record<ModCategory, string> = {
      Gameplay: 'ការលេងហ្គេម',
      Graphics: 'ក្រាហ្វិក',
      Audio: 'សំឡេង',
      UI: 'ចំណុចប្រទាក់',
      Other: 'ផ្សេងៗ',
    };
    return localize(language, item, khmer[item]);
  };

  const openAdd = () => {
    setEditing(null);
    setName('');
    setGameName('');
    setNotes('');
    setCategory('Other');
    setShowAdd(true);
  };

  const save = () => {
    if (!name.trim()) {
      Alert.alert('Mod name required', 'Enter a name for this metadata entry.');
      return;
    }
    if (editing) {
      updateData((current) => ({
        ...current,
        mods: current.mods.map((mod) =>
          mod.id === editing.id
            ? { ...mod, name: name.trim(), gameName: gameName.trim(), notes: notes.trim(), category }
            : mod,
        ),
      }));
      logActivity(`Updated mod entry: ${name.trim()}`, 'mod');
    } else {
      updateData((current) => ({
        ...current,
        mods: [
          {
            id: makeId('mod'),
            name: name.trim(),
            gameName: gameName.trim(),
            notes: notes.trim(),
            category,
            enabled: false,
            createdAt: Date.now(),
          },
          ...current.mods,
        ],
      }));
      logActivity(`Added mod metadata: ${name.trim()}`, 'mod');
    }
    setShowAdd(false);
  };

  const importModFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
      });
      if (result.canceled) return;
      const asset = result.assets[0];
      const extension = asset.name.split('.').pop()?.toLowerCase() ?? '';
      const supported = new Set(['zip', '7z', 'rar', 'asi', 'dll', 'lua', 'json', 'txt']);
      if (!supported.has(extension)) {
        Alert.alert(
          localize(language, 'Unsupported mod file', 'មិនគាំទ្រឯកសារមូដនេះទេ'),
          localize(language, 'Choose a ZIP, 7Z, RAR, ASI, DLL, LUA, JSON, or TXT file.', 'ជ្រើសឯកសារ ZIP, 7Z, RAR, ASI, DLL, LUA, JSON ឬ TXT។'),
        );
        return;
      }
      const saved = await copyToAppStorage(asset.uri, asset.name, 'mods');
      const fileId = makeId('file');
      const file: VaultFile = {
        id: fileId,
        name: asset.name,
        uri: saved.uri,
        sizeBytes: saved.sizeBytes,
        extension,
        importedAt: Date.now(),
        source: 'import',
      };
      const mod: ModRecord = {
        id: makeId('mod'),
        name: asset.name.replace(/\.[^.]+$/, ''),
        gameName: '',
        notes: 'Imported and stored locally. Not installed into a game.',
        category: 'Other',
        fileId,
        enabled: false,
        createdAt: Date.now(),
      };
      updateData((current) => ({
        ...current,
        files: [file, ...current.files],
        mods: [mod, ...current.mods],
      }));
      logActivity(`Imported mod package: ${asset.name}`, 'mod');
    } catch (error) {
      Alert.alert(localize(language, 'Mod import failed', 'នាំចូលមូដមិនបាន'), error instanceof Error ? error.message : localize(language, 'The selected mod file could not be copied.', 'មិនអាចចម្លងឯកសារមូដដែលបានជ្រើសទេ។'));
    }
  };

  const remove = (mod: ModRecord) => {
    Alert.alert(localize(language, 'Delete mod entry?', 'លុបមូដនេះ?'), `${mod.name} · ${localize(language, 'This removes the catalog entry, not the stored file.', 'វាលុបតែព័ត៌មានក្នុងបញ្ជី មិនលុបឯកសារដែលបានរក្សាទុកទេ។')}`, [
      { text: localize(language, 'Keep', 'រក្សាទុក'), style: 'cancel' },
      {
        text: localize(language, 'Delete', 'លុប'),
        style: 'destructive',
        onPress: () => {
          updateData((current) => ({
            ...current,
            mods: current.mods.filter((item) => item.id !== mod.id),
          }));
          logActivity(`Removed mod entry: ${mod.name}`, 'mod');
        },
      },
    ]);
  };

  return (
    <View style={{ gap: 14 }}>
      <Panel style={{ gap: 10 }}>
        <View style={styles.toolTitle}>
          <Ionicons name="extension-puzzle-outline" size={19} color={colors.primary} />
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
            {localize(language, 'Mod catalog', 'បញ្ជីមូដ')}
          </AppText>
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          {localize(
            language,
            'Mod packages can be stored and cataloged here. Nothing is installed into a game, loaded, or applied without a compatible game engine.',
            'អាចរក្សាទុក និងរៀបចំកញ្ចប់មូដនៅទីនេះ។ មិនមានការដំឡើង ឬអនុវត្តទៅក្នុងហ្គេមទេ ព្រោះមិនមានម៉ាស៊ីនហ្គេមដែលគាំទ្រ។',
          )}
        </AppText>
        <View style={{ gap: 8 }}>
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 12 }}>Original control icon pack · {CONTROL_ICONS.length} PNG</AppText>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {CONTROL_ICONS.map((item) => (
              <View key={item.name} style={{ width: 66, alignItems: 'center', gap: 4 }}>
                <View style={{ width: 54, height: 54, borderRadius: 12, backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center' }}>
                  <Image source={item.image} resizeMode="contain" style={{ width: 44, height: 44 }} />
                </View>
                <AppText numberOfLines={1} style={{ color: colors.mutedForeground, fontSize: 8 }}>{item.name.replace('icon_', '').replace('.png', '').replaceAll('_', ' ')}</AppText>
              </View>
            ))}
          </ScrollView>
        </View>
        <View style={styles.twoButtons}>
          <View style={{ flex: 1 }}>
            <ActionButton label={localize(language, 'Import mod file', 'នាំចូលឯកសារមូដ')} icon="folder-open-outline" onPress={() => void importModFile()} />
          </View>
          <View style={{ flex: 1 }}>
            <ActionButton label={localize(language, 'Add mod entry', 'បន្ថែមមូដ')} icon="add" secondary onPress={openAdd} testID="mods-add" />
          </View>
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>
          {localize(language, 'Mod metadata and history are included in app backups; imported files stay in Game Files.', 'ព័ត៌មានមូដ និងប្រវត្តិត្រូវបានបញ្ចូលក្នុងការបម្រុងទុក។ ឯកសារនាំចូលនៅក្នុងឯកសារហ្គេម។')}
        </AppText>
      </Panel>
      <View style={styles.choiceRow}>
        {(['All', ...categories] as const).map((item) => {
          const selected = filter === item;
          return (
            <Pressable
              key={item}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              onPress={() => setFilter(item)}
              style={[
                styles.choiceChip,
                { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? `${colors.primary}20` : colors.card },
              ]}
            >
              <AppText style={{ color: selected ? colors.primary : colors.foreground, fontSize: 9 }}>{categoryLabel(item)}</AppText>
            </Pressable>
          );
        })}
      </View>
      {visibleMods.length === 0 ? (
        <Panel>
          <EmptyState
            icon="extension-puzzle-outline"
            title={localize(language, 'No mod entries', 'មិនទាន់មានមូដទេ')}
            detail={localize(language, 'Add metadata or import a mod package to track it here.', 'បន្ថែមព័ត៌មាន ឬនាំចូលកញ្ចប់មូដដើម្បីតាមដាននៅទីនេះ។')}
          />
        </Panel>
      ) : (
        <View style={{ gap: 10 }}>
          {visibleMods.map((mod) => {
            const hasLocalFile = !!mod.fileId && data.files.some((file) => file.id === mod.fileId && !!file.uri);
            return (
              <Panel key={mod.id} style={{ gap: 11 }}>
              <View style={styles.downloadHeader}>
                <View style={{ flex: 1, gap: 4 }}>
                  <AppText weight="bold" style={{ color: colors.foreground, fontSize: 13 }}>{mod.name}</AppText>
                  <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>{mod.gameName || 'No game selected'}</AppText>
                </View>
                <IconButton
                  icon={mod.enabled ? 'toggle' : 'toggle-outline'}
                  label={mod.enabled ? 'Disable entry' : 'Enable entry'}
                  color={mod.enabled ? colors.primary : colors.mutedForeground}
                  onPress={() => {
                    updateData((current) => ({
                      ...current,
                      mods: current.mods.map((item) => item.id === mod.id ? { ...item, enabled: !item.enabled } : item),
                    }));
                    logActivity(`${mod.enabled ? 'Disabled' : 'Enabled'} mod catalog entry: ${mod.name}`, 'mod');
                  }}
                />
                <IconButton
                  icon="create-outline"
                  label="Edit mod metadata"
                  onPress={() => {
                    setEditing(mod);
                    setName(mod.name);
                    setGameName(mod.gameName);
                    setNotes(mod.notes);
                    setCategory(mod.category ?? 'Other');
                    setShowAdd(true);
                  }}
                />
                <IconButton icon="trash-outline" label="Delete mod entry" color={colors.destructive} onPress={() => remove(mod)} />
              </View>
              {mod.notes ? <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>{mod.notes}</AppText> : null}
              <View style={styles.choiceRow}>
                <Tag label={categoryLabel(mod.category ?? 'Other')} />
                <Tag
                  label={mod.enabled
                    ? localize(language, 'Tracked active · not installed', 'សកម្មក្នុងបញ្ជី · មិនបានដំឡើង')
                    : hasLocalFile
                      ? localize(language, 'Stored locally · not installed', 'រក្សាទុកក្នុងឧបករណ៍ · មិនបានដំឡើង')
                      : localize(language, 'Not installed', 'មិនទាន់ដំឡើង')}
                  tone={mod.enabled ? 'accent' : 'neutral'}
                />
              </View>
              </Panel>
            );
          })}
        </View>
      )}
      <Sheet visible={showAdd} title={editing ? 'Edit mod entry' : 'New mod entry'} onClose={() => setShowAdd(false)}>
          <FormField label={localize(language, 'Mod name', 'ឈ្មោះមូដ')} value={name} onChangeText={setName} placeholder={localize(language, 'Name this mod', 'ដាក់ឈ្មោះមូដនេះ')} />
          <FormField label={localize(language, 'Game profile', 'ប្រវត្តិរូបហ្គេម')} value={gameName} onChangeText={setGameName} placeholder={localize(language, 'Optional game name', 'ឈ្មោះហ្គេម (ស្រេចចិត្ត)')} />
        <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{localize(language, 'Category', 'ប្រភេទ')}</AppText>
        <View style={styles.choiceRow}>
          {categories.map((item) => (
            <Pressable
              key={item}
              accessibilityRole="button"
              accessibilityState={{ selected: category === item }}
              onPress={() => setCategory(item)}
              style={[
                styles.choiceChip,
                { borderColor: category === item ? colors.primary : colors.border, backgroundColor: category === item ? `${colors.primary}20` : colors.card },
              ]}
            >
              <AppText style={{ color: category === item ? colors.primary : colors.foreground, fontSize: 9 }}>{categoryLabel(item)}</AppText>
            </Pressable>
          ))}
        </View>
        <FormField label={localize(language, 'Notes', 'កំណត់ចំណាំ')} value={notes} onChangeText={setNotes} placeholder={localize(language, 'Version, source, or dependency notes', 'កំណែ ប្រភព ឬព័ត៌មានអាស្រ័យ')} multiline />
        <ActionButton label={editing ? localize(language, 'Save changes', 'រក្សាទុកការកែប្រែ') : localize(language, 'Save entry', 'រក្សាទុកមូដ')} icon="checkmark" onPress={save} testID="mods-save" />
      </Sheet>
      <Panel style={{ gap: 9 }}>
        <AppText weight="bold" style={{ color: colors.foreground, fontSize: 12 }}>{localize(language, 'Mod history', 'ប្រវត្តិមូដ')}</AppText>
        {data.activity.filter((item) => item.kind === 'mod').slice(-5).reverse().length === 0 ? (
          <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>{localize(language, 'No mod activity recorded yet.', 'មិនទាន់មានសកម្មភាពមូដទេ។')}</AppText>
        ) : (
          data.activity.filter((item) => item.kind === 'mod').slice(-5).reverse().map((item) => (
            <AppText key={item.id} style={{ color: colors.mutedForeground, fontSize: 10 }}>
              {new Date(item.createdAt).toLocaleDateString()} · {item.label}
            </AppText>
          ))
        )}
      </Panel>
    </View>
  );
}

function ControlsTool() {
  const colors = useAppColors();
  const { data, updateData, logActivity } = useAppState();
  const language = data.preferences.language;
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [editingPreset, setEditingPreset] = useState<ControlPreset | null>(null);

  const setPreset = (id: string, update: Partial<ControlPreset>) => {
    updateData((current) => ({
      ...current,
      controls: current.controls.map((preset) =>
        preset.id === id ? { ...preset, ...update } : preset,
      ),
    }));
  };

  const applyPreset = (preset: ControlPreset) => {
    updateData((current) => ({
      ...current,
      controls: current.controls.map((entry) => ({ ...entry, active: entry.id === preset.id })),
    }));
    logActivity(`Applied control profile: ${preset.name}`, 'settings');
  };

  const addPreset = () => {
    if (!name.trim()) {
      Alert.alert('Preset name required', 'Enter a name for this control profile.');
      return;
    }
    if (editingPreset) {
      updateData((current) => ({
        ...current,
        controls: current.controls.map((entry) =>
          entry.id === editingPreset.id ? { ...entry, name: name.trim() } : entry,
        ),
      }));
      logActivity(`Renamed control preset: ${name.trim()}`, 'settings');
    } else {
      const preset: ControlPreset = {
        id: makeId('controls'),
        name: name.trim(),
        kind: 'Custom',
        sensitivity: 60,
        movementSensitivity: 60,
        cameraSensitivity: 60,
        vehicleSensitivity: 60,
        joystickSide: 'left',
        opacity: 75,
        buttonScale: 100,
        active: false,
        builtIn: false,
      };
      updateData((current) => ({ ...current, controls: [...current.controls, preset] }));
      logActivity(`Created control preset: ${preset.name}`, 'settings');
    }
    setName('');
    setEditingPreset(null);
    setShowAdd(false);
  };

  const adjust = (
    preset: ControlPreset,
    key: 'sensitivity' | 'movementSensitivity' | 'cameraSensitivity' | 'vehicleSensitivity' | 'opacity' | 'buttonScale',
    direction: number,
  ) => {
    const currentValue = preset[key] ?? preset.sensitivity;
    const next = Math.max(25, Math.min(150, currentValue + direction * 5));
    setPreset(preset.id, { [key]: next });
  };

  const remove = (preset: ControlPreset) => {
    if (preset.builtIn) return;
    Alert.alert('Delete preset?', `${preset.name} will be removed.`, [
      { text: 'Keep', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => updateData((current) => ({
          ...current,
          controls: current.controls.filter((entry) => entry.id !== preset.id),
        })),
      },
    ]);
  };

  const duplicate = (preset: ControlPreset) => {
    const copy: ControlPreset = {
      ...preset,
      id: makeId('controls'),
      name: `${preset.name} Copy`,
      active: false,
      builtIn: false,
    };
    updateData((current) => ({ ...current, controls: [...current.controls, copy] }));
    logActivity(`Duplicated control preset: ${preset.name}`, 'settings');
  };

  const restoreDefaults = () => {
    Alert.alert(
      'Restore control defaults?',
      'This removes custom control profiles and resets the built-in presets.',
      [
        { text: 'Keep profiles', style: 'cancel' },
        {
          text: 'Restore defaults',
          style: 'destructive',
          onPress: () => updateData((current) => ({
            ...current,
            controls: defaultControls(),
          })),
        },
      ],
    );
  };

  return (
    <View style={{ gap: 14 }}>
      <Panel style={{ gap: 10 }}>
        <View style={styles.toolTitle}>
          <Ionicons name="game-controller-outline" size={19} color={colors.primary} />
          <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
            {localize(language, 'Touch controls', 'ការគ្រប់គ្រងប៉ះ')}
          </AppText>
        </View>
        <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
          {localize(
            language,
            'Tune saved values and preview a touch layout. This companion app does not send input to a game runtime.',
            'កែតម្រូវតម្លៃ និងមើលប្លង់បញ្ជា។ កម្មវិធីនេះមិនបញ្ជូនការប៉ះទៅម៉ាស៊ីនហ្គេមទេ។',
          )}
        </AppText>
        <View style={styles.twoButtons}>
          <View style={{ flex: 1 }}>
            <ActionButton
              label={localize(language, 'Create custom', 'បង្កើតផ្ទាល់ខ្លួន')}
              icon="add"
              onPress={() => {
                setEditingPreset(null);
                setName('');
                setShowAdd(true);
              }}
              testID="controls-add"
            />
          </View>
          <View style={{ flex: 1 }}>
            <ActionButton label={localize(language, 'Restore defaults', 'ស្ដារលំនាំដើម')} icon="refresh-outline" secondary onPress={restoreDefaults} />
          </View>
        </View>
      </Panel>
      {data.controls.map((preset) => (
        <Panel key={preset.id} style={{ gap: 13 }}>
          <View style={styles.downloadHeader}>
            <View style={{ flex: 1, gap: 4 }}>
              <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>{preset.name}</AppText>
              <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>{preset.kind} preset</AppText>
            </View>
            {preset.active ? <Tag label="Active profile" tone="accent" /> : null}
            <IconButton
              icon="copy-outline"
              label="Duplicate preset"
              onPress={() => duplicate(preset)}
            />
            <IconButton
              icon="create-outline"
              label="Rename preset"
              onPress={() => {
                setEditingPreset(preset);
                setName(preset.name);
                setShowAdd(true);
              }}
            />
            {!preset.builtIn ? <IconButton icon="trash-outline" label="Delete preset" color={colors.destructive} onPress={() => remove(preset)} /> : null}
          </View>
          <ValueAdjuster label={localize(language, 'Movement sensitivity', 'ភាពរសើបចលនា')} value={preset.movementSensitivity ?? preset.sensitivity} onDecrease={() => adjust(preset, 'movementSensitivity', -1)} onIncrease={() => adjust(preset, 'movementSensitivity', 1)} />
          <ValueAdjuster label={localize(language, 'Camera sensitivity', 'ភាពរសើបកាមេរ៉ា')} value={preset.cameraSensitivity ?? preset.sensitivity} onDecrease={() => adjust(preset, 'cameraSensitivity', -1)} onIncrease={() => adjust(preset, 'cameraSensitivity', 1)} />
          <ValueAdjuster label={localize(language, 'Vehicle sensitivity', 'ភាពរសើបយានយន្ត')} value={preset.vehicleSensitivity ?? preset.sensitivity} onDecrease={() => adjust(preset, 'vehicleSensitivity', -1)} onIncrease={() => adjust(preset, 'vehicleSensitivity', 1)} />
          <ValueAdjuster label={localize(language, 'Button opacity', 'ភាពស្រអាប់ប៊ូតុង')} value={preset.opacity} onDecrease={() => adjust(preset, 'opacity', -1)} onIncrease={() => adjust(preset, 'opacity', 1)} suffix="%" />
          <ValueAdjuster label={localize(language, 'Button scale', 'ទំហំប៊ូតុង')} value={preset.buttonScale} onDecrease={() => adjust(preset, 'buttonScale', -1)} onIncrease={() => adjust(preset, 'buttonScale', 1)} suffix="%" />
          <View style={{ gap: 7 }}>
            <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{localize(language, 'Virtual joystick side', 'ទីតាំងយ៉យស្ទីកនិម្មិត')}</AppText>
            <View style={styles.choiceRow}>
              {(['left', 'right'] as const).map((side) => {
                const selected = (preset.joystickSide ?? 'left') === side;
                return (
                  <Pressable
                    key={side}
                    accessibilityRole="button"
                    accessibilityState={{ selected }}
                    onPress={() => setPreset(preset.id, { joystickSide: side })}
                    style={[
                      styles.choiceChip,
                      { borderColor: selected ? colors.primary : colors.border, backgroundColor: selected ? `${colors.primary}20` : colors.card },
                    ]}
                  >
                    <AppText style={{ color: selected ? colors.primary : colors.foreground, fontSize: 10 }}>
                      {side === 'left'
                        ? localize(language, 'Left-handed', 'ដៃឆ្វេង')
                        : localize(language, 'Right-handed', 'ដៃស្ដាំ')}
                    </AppText>
                  </Pressable>
                );
              })}
            </View>
          </View>
          <View style={[styles.controllerPreview, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <AppText style={{ color: colors.mutedForeground, fontSize: 9, position: 'absolute', top: 8, alignSelf: 'center' }}>
              {localize(language, 'LAYOUT PREVIEW · NO GAME INPUT', 'មើលប្លង់ · មិនបញ្ជាទៅហ្គេម')}
            </AppText>
            <View style={{ flexDirection: (preset.joystickSide ?? 'left') === 'left' ? 'row' : 'row-reverse', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
              <View style={[styles.joystickBase, { borderColor: colors.border, backgroundColor: colors.card }]}>
                <View style={[styles.joystickCap, { backgroundColor: `${colors.primary}60`, borderColor: colors.primary }]} />
                <AppText style={{ color: colors.mutedForeground, fontSize: 8, position: 'absolute', bottom: 8 }}>{localize(language, 'MOVE', 'ចលនា')}</AppText>
              </View>
              <View style={{ flex: 1, alignItems: 'center', gap: 8 }}>
                <View style={[styles.previewAction, { borderColor: colors.border, backgroundColor: colors.card }]}>
                  <AppText style={{ color: colors.foreground, fontSize: 9 }}>{localize(language, 'CAMERA / AIM', 'កាមេរ៉ា / តម្រង់')}</AppText>
                </View>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  {[
                    [localize(language, 'BRAKE', 'ហ្វ្រាំង'), 'brake'],
                    [localize(language, 'DRIVE', 'បើកបរ'), 'drive'],
                    [localize(language, 'ACTION', 'សកម្មភាព'), 'action'],
                  ].map(([label, key]) => (
                    <View key={key} style={[styles.previewButton, { borderColor: colors.border, backgroundColor: colors.card }]}>
                      <AppText style={{ color: colors.mutedForeground, fontSize: 8 }}>{label}</AppText>
                    </View>
                  ))}
                </View>
              </View>
              <View style={[styles.joystickBase, { borderColor: colors.border, backgroundColor: colors.card }]}>
                <View style={[styles.joystickCap, { backgroundColor: colors.secondary, borderColor: colors.border }]} />
                <AppText style={{ color: colors.mutedForeground, fontSize: 8, position: 'absolute', bottom: 8 }}>{localize(language, 'LOOK', 'មើល')}</AppText>
              </View>
            </View>
          </View>
          {!preset.active ? <ActionButton label={localize(language, 'Load profile', 'ផ្ទុកប្រវត្តិរូប')} icon="checkmark" secondary onPress={() => applyPreset(preset)} /> : null}
        </Panel>
      ))}
      <Sheet
        visible={showAdd}
        title={editingPreset ? 'Rename control preset' : 'New control preset'}
        onClose={() => {
          setShowAdd(false);
          setEditingPreset(null);
        }}
      >
        <FormField label="Preset name" value={name} onChangeText={setName} placeholder="For example, My setup" />
        <ActionButton label={editingPreset ? 'Save name' : 'Create preset'} icon="checkmark" onPress={addPreset} />
      </Sheet>
    </View>
  );
}

function ValueAdjuster({
  label,
  value,
  suffix = '',
  onDecrease,
  onIncrease,
}: {
  label: string;
  value: number;
  suffix?: string;
  onDecrease: () => void;
  onIncrease: () => void;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.valueRow}>
      <AppText style={{ flex: 1, color: colors.mutedForeground, fontSize: 11 }}>{label}</AppText>
      <IconButton icon="remove" label={`Reduce ${label}`} onPress={onDecrease} />
      <AppText weight="bold" style={{ minWidth: 47, textAlign: 'center', color: colors.foreground, fontSize: 12 }}>
        {value}{suffix}
      </AppText>
      <IconButton icon="add" label={`Increase ${label}`} onPress={onIncrease} />
    </View>
  );
}

function MoreTools() {
  const colors = useAppColors();
  const labels = useLabels();
  const { data, updateData, logActivity, persistenceError } = useAppState();
  const language = data.preferences.language;
  const [query, setQuery] = useState('');
  const [deviceInfo, setDeviceInfo] = useState<{ free: number; total: number } | null>(null);
  const [showSearch, setShowSearch] = useState(false);
  const searchResults = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return [];
    return [
      ...data.games.filter((item) => item.name.toLowerCase().includes(term)).map((item) => ({ label: item.name, kind: 'Game' })),
      ...data.files.filter((item) => item.name.toLowerCase().includes(term)).map((item) => ({ label: item.name, kind: 'File' })),
      ...data.mods.filter((item) => item.name.toLowerCase().includes(term)).map((item) => ({ label: item.name, kind: 'Mod' })),
      ...data.downloads.filter((item) => item.fileName.toLowerCase().includes(term)).map((item) => ({ label: item.fileName, kind: 'Download' })),
      ...data.activity.filter((item) => item.label.toLowerCase().includes(term)).map((item) => ({ label: item.label, kind: 'Activity' })),
    ];
  }, [data.activity, data.downloads, data.files, data.games, data.mods, query]);

  const exportBackup = async () => {
    try {
      if (!cacheDirectory) throw new Error('The temporary file folder is unavailable.');
      const exportData = {
        ...data,
        files: data.files.map(({ uri: _uri, ...file }) => ({ ...file, uri: '' })),
        audioTracks: data.audioTracks.map(({ uri: _uri, ...track }) => ({ ...track, uri: '' })),
      };
      const path = `${cacheDirectory}khmer-game-port-backup-${Date.now()}.json`;
      await writeAsStringAsync(path, JSON.stringify(exportData, null, 2), { encoding: EncodingType.UTF8 });
      if (!(await Sharing.isAvailableAsync())) throw new Error('File sharing is not available on this device.');
      await Sharing.shareAsync(path, { mimeType: 'application/json', dialogTitle: 'Export local backup' });
      logActivity('Exported local settings backup', 'backup');
    } catch (error) {
      Alert.alert('Backup export failed', error instanceof Error ? error.message : 'The backup could not be exported.');
    }
  };

  const importBackup = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/json',
        copyToCacheDirectory: true,
      });
      if (result.canceled) return;
      const asset = result.assets[0];
      const raw = await readAsStringAsync(asset.uri, {
        encoding: EncodingType.UTF8,
      });
      const parsed = JSON.parse(raw) as typeof data;
      if (
        parsed.version !== 1 ||
        !Array.isArray(parsed.games) ||
        !Array.isArray(parsed.files) ||
        !Array.isArray(parsed.downloads) ||
        !Array.isArray(parsed.mods) ||
        !Array.isArray(parsed.controls) ||
        !parsed.preferences ||
        typeof parsed.preferences !== 'object'
      ) {
        throw new Error('This file is not a supported KHMER GAME PORT backup.');
      }
      Alert.alert('Restore this backup?', 'Current local profiles and settings will be replaced. File URIs are not portable, so the original files are not restored.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Restore',
          style: 'destructive',
          onPress: () => {
            updateData(() => ({
              ...data,
              ...parsed,
              files: (parsed.files ?? []).map((file) => ({ ...file, uri: '' })),
              audioTracks: (parsed.audioTracks ?? []).map((track) => ({ ...track, uri: '' })),
            }));
            logActivity('Restored local metadata backup', 'backup');
          },
        },
      ]);
    } catch (error) {
      Alert.alert('Backup not restored', error instanceof Error ? error.message : 'The selected backup could not be read.');
    }
  };

  const checkDeviceStorage = async () => {
    try {
      const [free, total] = await Promise.all([
        getFreeDiskStorageAsync(),
        getTotalDiskCapacityAsync(),
      ]);
      setDeviceInfo({ free, total });
    } catch {
      setDeviceInfo(null);
      Alert.alert('Storage unavailable', 'iOS did not provide device storage details.');
    }
  };

  const clearActivity = () => {
    Alert.alert('Clear activity history?', 'This removes the in-app log only. It does not delete your profiles or files.', [
      { text: 'Keep', style: 'cancel' },
      {
        text: 'Clear history',
        style: 'destructive',
        onPress: () => updateData((current) => ({ ...current, activity: [] })),
      },
    ]);
  };

  return (
    <View style={{ gap: 14 }}>
      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Search everything', 'ស្វែងរកទាំងអស់')} />
        <ActionButton label={localize(language, 'Open smart search', 'បើកការស្វែងរក')} icon="search-outline" secondary onPress={() => setShowSearch((open) => !open)} />
        {showSearch ? (
          <View style={{ gap: 10 }}>
            <SearchField value={query} onChangeText={setQuery} placeholder={localize(language, 'Games, files, mods, downloads…', 'ហ្គេម ឯកសារ មូដ និងការទាញយក…')} />
            {query.trim() ? (
              <Panel style={{ gap: 11 }}>
                {searchResults.length === 0 ? (
                  <AppText style={{ color: colors.mutedForeground, fontSize: 12 }}>{localize(language, 'No local matches.', 'រកមិនឃើញក្នុងឧបករណ៍ទេ។')}</AppText>
                ) : searchResults.slice(0, 12).map((result, index) => (
                  <View key={`${result.kind}-${result.label}-${index}`} style={styles.searchResult}>
                    <AppText numberOfLines={1} style={{ flex: 1, color: colors.foreground, fontSize: 11 }}>{result.label}</AppText>
                    <Tag label={localize(language, result.kind, ({
                      Game: 'ហ្គេម',
                      File: 'ឯកសារ',
                      Mod: 'មូដ',
                      Download: 'ទាញយក',
                      Activity: 'សកម្មភាព',
                    } as Record<string, string>)[result.kind] ?? result.kind)} />
                  </View>
                ))}
              </Panel>
            ) : null}
          </View>
        ) : null}
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Backup and restore', 'បម្រុងទុក និងស្ដារ')} />
        <Panel style={{ gap: 10 }}>
          <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
            {localize(language, 'Exports preferences and metadata, not the actual game files. Imported files must be selected again on a new device.', 'នាំចេញចំណូលចិត្ត និងព័ត៌មាន មិនមែនឯកសារហ្គេមពិតទេ។ ត្រូវជ្រើសឯកសារឡើងវិញនៅឧបករណ៍ថ្មី។')}
          </AppText>
          <View style={styles.twoButtons}>
            <View style={{ flex: 1 }}><ActionButton label={localize(language, 'Export backup', 'នាំចេញការបម្រុងទុក')} icon="share-outline" onPress={() => void exportBackup()} /></View>
            <View style={{ flex: 1 }}><ActionButton label={localize(language, 'Restore backup', 'ស្ដារការបម្រុងទុក')} icon="refresh-outline" secondary onPress={() => void importBackup()} /></View>
          </View>
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Device and diagnostics', 'ឧបករណ៍ និងការវិនិច្ឆ័យ')} />
        <Panel style={{ gap: 12 }}>
          <InfoRow label={localize(language, 'Device', 'ឧបករណ៍')} value={Device.modelName ?? Device.deviceName ?? labels.unavailable} />
          <InfoRow label={localize(language, 'Operating system', 'ប្រព័ន្ធប្រតិបត្តិការ')} value={Device.osVersion ?? labels.unavailable} />
          <InfoRow label={localize(language, 'App version', 'កំណែកម្មវិធី')} value={Application.nativeApplicationVersion ?? labels.unavailable} />
          <InfoRow label={localize(language, 'Build', 'Build')} value={Application.nativeBuildVersion ?? labels.unavailable} />
          <InfoRow
            label={localize(language, 'Permissions', 'សិទ្ធិចូលប្រើ')}
            value={localize(
              data.preferences.language,
              'No camera, location, or microphone access. Files are opened only after you choose them.',
              'មិនស្នើសុំកាមេរ៉ា ទីតាំង ឬមីក្រូហ្វូនទេ។ ឯកសារត្រូវបានបើកតែបន្ទាប់ពីអ្នកជ្រើសរើស។',
            )}
          />
          <InfoRow label={localize(language, 'Game engine', 'ម៉ាស៊ីនហ្គេម')} value={localize(language, 'Not installed · no native runtime bridge', 'មិនបានដំឡើង · គ្មានស្ពានភ្ជាប់ម៉ាស៊ីនដំណើរការ')} />
          {deviceInfo ? (
            <>
              <InfoRow label={localize(language, 'Available storage', 'ទំហំផ្ទុកនៅសល់')} value={formatBytes(deviceInfo.free)} />
              <InfoRow label={localize(language, 'Total device storage', 'ទំហំផ្ទុកសរុប')} value={formatBytes(deviceInfo.total)} />
            </>
          ) : (
            <ActionButton label={localize(language, 'Read device storage', 'ពិនិត្យទំហំផ្ទុក')} icon="refresh-outline" secondary onPress={() => void checkDeviceStorage()} />
          )}
          <InfoRow
            label={localize(language, 'App file service', 'ឯកសារក្នុងកម្មវិធី')}
            value={`${data.files.filter((file) => !!file.uri).length} local files · ${formatBytes(data.files.reduce((sum, file) => sum + (file.uri ? file.sizeBytes : 0), 0))}`}
          />
          <InfoRow label={localize(language, 'Cloud sync', 'សមកាលកម្មពពក')} value={localize(language, 'Not configured · no account or backend', 'មិនទាន់កំណត់ · គ្មានគណនី ឬ backend')} />
          <InfoRow label={localize(language, 'Last persistence status', 'ស្ថានភាពរក្សាទុកចុងក្រោយ')} value={persistenceError ?? localize(language, 'Saved on this device', 'បានរក្សាទុកក្នុងឧបករណ៍នេះ')} />
        </Panel>
      </View>

      <View style={{ gap: 12 }}>
        <SectionTitle title={localize(language, 'Activity history', 'ប្រវត្តិសកម្មភាព')} action={localize(language, 'Clear', 'សម្អាត')} onAction={clearActivity} />
        <Panel style={{ gap: 12 }}>
          {data.activity.length === 0 ? (
            <AppText style={{ color: colors.mutedForeground, fontSize: 11 }}>{localize(language, 'No recorded activity.', 'មិនទាន់មានសកម្មភាពកត់ត្រាទេ។')}</AppText>
          ) : (
            [...data.activity].reverse().slice(0, 12).map((item) => (
              <View key={item.id} style={styles.activityLine}>
                <View style={[styles.activityMark, { backgroundColor: colors.primary }]} />
                <AppText style={{ color: colors.foreground, fontSize: 11, flex: 1 }}>{item.label}</AppText>
                <AppText style={{ color: colors.mutedForeground, fontSize: 9 }}>
                  {new Date(item.createdAt).toLocaleDateString()}
                </AppText>
              </View>
            ))
          )}
        </Panel>
      </View>
    </View>
  );
}

function RadioTool() {
  const colors = useAppColors();
  const { data, updateData, logActivity } = useAppState();
  const language = data.preferences.language;

  const importAudio = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'audio/*',
        multiple: true,
        copyToCacheDirectory: true,
      });
      if (result.canceled) return;
      for (const asset of result.assets) {
        const saved = await copyToAppStorage(asset.uri, asset.name, 'audio');
        updateData((current) => ({
          ...current,
          audioTracks: [
            { id: makeId('track'), name: saved.name, uri: saved.uri, addedAt: Date.now() },
            ...current.audioTracks,
          ],
        }));
      }
      logActivity('Imported local audio', 'file');
    } catch (error) {
      Alert.alert('Audio import failed', error instanceof Error ? error.message : 'The audio files could not be imported.');
    }
  };

  return (
    <View style={{ gap: 12 }}>
      <View style={styles.toolTitle}>
        <Ionicons name="radio-outline" size={19} color={colors.primary} />
        <AppText weight="bold" style={{ color: colors.foreground, fontSize: 14 }}>
          {localize(language, 'Local radio library', 'បណ្ណាល័យវិទ្យុក្នុងកម្មវិធី')}
        </AppText>
      </View>
      <AppText style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>
        {localize(
          language,
          'Import audio you own and play it inside this app. Playback is not connected to GTA V.',
          'នាំចូលសំឡេងដែលអ្នកមាន ហើយចាក់ក្នុងកម្មវិធីនេះ។ ការចាក់សំឡេងមិនភ្ជាប់ទៅ GTA V ទេ។',
        )}
      </AppText>
      <AudioCenter onImport={() => void importAudio()} />
    </View>
  );
}

function AudioCenter({ onImport }: { onImport: () => void }) {
  const colors = useAppColors();
  const { data, updateData } = useAppState();
  const language = data.preferences.language;
  const player = useAudioPlayer(null);
  const status = useAudioPlayerStatus(player);
  const [activeTrackId, setActiveTrackId] = useState<string | null>(null);
  const [volume, setVolume] = useState(0.8);

  React.useEffect(() => {
    player.volume = volume;
  }, [player, volume]);

  const playTrack = (id: string, uri: string) => {
    if (activeTrackId === id && status.playing) {
      player.pause();
      return;
    }
    if (activeTrackId !== id) {
      player.replace(uri);
      setActiveTrackId(id);
    }
    player.play();
  };

  const stopTrack = () => {
    player.pause();
    void player.seekTo(0);
    setActiveTrackId(null);
  };

  return (
    <Panel style={{ gap: 12 }}>
      {data.audioTracks.length === 0 ? (
        <>
          <EmptyState
            icon="musical-notes-outline"
            title={localize(language, 'Your audio library is empty', 'បណ្ណាល័យសំឡេងរបស់អ្នកទទេ')}
            detail={localize(language, 'Import audio you own to play it locally in the app.', 'នាំចូលឯកសារសំឡេងរបស់អ្នក ដើម្បីចាក់ក្នុងកម្មវិធី។')}
          />
          <ActionButton label={localize(language, 'Choose audio', 'ជ្រើសសំឡេង')} icon="folder-open-outline" onPress={onImport} />
        </>
      ) : (
        <>
          {data.audioTracks.map((track) => (
            <View key={track.id} style={styles.audioLine}>
              <IconButton
                icon={activeTrackId === track.id && status.playing ? 'pause-circle' : 'play-circle'}
                label={activeTrackId === track.id && status.playing
                  ? localize(language, 'Pause track', 'ផ្អាកសំឡេង')
                  : `${localize(language, 'Play', 'ចាក់')} ${track.name}`}
                color={colors.primary}
                onPress={() => {
                  if (!track.uri) {
                    Alert.alert(
                      localize(language, 'Audio file unavailable', 'មិនមានឯកសារសំឡេង'),
                      localize(language, 'This backup contains track metadata only. Import the audio file again to play it.', 'ការបម្រុងទុកនេះមានតែព័ត៌មានសំឡេង។ សូមនាំចូលឯកសារម្ដងទៀត។'),
                    );
                    return;
                  }
                  playTrack(track.id, track.uri);
                }}
              />
              <AppText numberOfLines={1} style={{ color: colors.foreground, flex: 1, fontSize: 11 }}>{track.name}</AppText>
              {track.uri ? (
                activeTrackId === track.id ? <Tag label={status.playing ? localize(language, 'Playing', 'កំពុងចាក់') : localize(language, 'Selected', 'បានជ្រើស')} tone="accent" /> : null
              ) : (
                <Tag label={localize(language, 'Unavailable on device', 'មិនមានក្នុងឧបករណ៍')} />
              )}
              <IconButton
                icon="trash-outline"
                label={`${localize(language, 'Remove', 'លុប')} ${track.name}`}
                color={colors.destructive}
                onPress={() => Alert.alert(
                  localize(language, 'Remove audio track?', 'លុបបទសំឡេង?'),
                  `${track.name} · ${localize(language, 'This app copy will be removed.', 'ច្បាប់ចម្លងក្នុងកម្មវិធីនឹងត្រូវលុប។')}`,
                  [
                  { text: localize(language, 'Keep', 'រក្សាទុក'), style: 'cancel' },
                  {
                    text: localize(language, 'Remove', 'លុប'),
                    style: 'destructive',
                    onPress: async () => {
                      if (track.uri) await deleteAsync(track.uri, { idempotent: true }).catch(() => undefined);
                      updateData((current) => ({
                        ...current,
                        audioTracks: current.audioTracks.filter((entry) => entry.id !== track.id),
                      }));
                    },
                  },
                ])}
              />
            </View>
          ))}
          <ActionButton label={localize(language, 'Add local audio', 'បន្ថែមសំឡេងក្នុងឧបករណ៍')} icon="add" secondary onPress={onImport} />
          <ValueAdjuster
            label={localize(language, 'Playback volume', 'កម្រិតសំឡេង')}
            value={Math.round(volume * 100)}
            suffix="%"
            onDecrease={() => setVolume((current) => Math.max(0, Math.round((current - 0.1) * 10) / 10))}
            onIncrease={() => setVolume((current) => Math.min(1, Math.round((current + 0.1) * 10) / 10))}
          />
          {activeTrackId ? <ActionButton label={localize(language, 'Stop playback', 'បញ្ឈប់ការចាក់')} icon="stop-circle-outline" secondary onPress={stopTrack} /> : null}
        </>
      )}
    </Panel>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  const colors = useAppColors();
  return (
    <View style={styles.infoRow}>
      <AppText style={{ color: colors.mutedForeground, fontSize: 11, flex: 1 }}>{label}</AppText>
      <AppText numberOfLines={2} style={{ color: colors.foreground, fontSize: 11, textAlign: 'right', flex: 1.2 }}>{value}</AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  pageHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  toolCounter: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 9, paddingHorizontal: 10, borderRadius: 12, borderWidth: 1 },
  segmentScroller: { borderRadius: 16, borderWidth: 1 },
  segmentRow: { flexDirection: 'row', padding: 5, gap: 3 },
  segment: { width: 70, minHeight: 55, borderRadius: 12, alignItems: 'center', justifyContent: 'center', gap: 5 },
  toolTitle: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  downloadHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  progressTrack: { height: 6, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: 6, borderRadius: 4 },
  valueRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  twoButtons: { flexDirection: 'row', gap: 8 },
  searchResult: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  activityLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  activityMark: { width: 5, height: 5, borderRadius: 3 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 2 },
  audioLine: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  choiceRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 6 },
  choiceChip: { borderWidth: 1, paddingVertical: 7, paddingHorizontal: 9, borderRadius: 10 },
  controllerPreview: { minHeight: 135, borderWidth: 1, borderRadius: 16, justifyContent: 'center', padding: 12, paddingTop: 28, overflow: 'hidden' },
  joystickBase: { width: 68, height: 68, borderWidth: 1, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  joystickCap: { width: 30, height: 30, borderWidth: 1, borderRadius: 16 },
  previewAction: { minWidth: 88, minHeight: 32, borderWidth: 1, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  previewButton: { minWidth: 45, height: 28, borderWidth: 1, borderRadius: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
});
