import React, { useCallback, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import { Ionicons } from '@expo/vector-icons';
import { AppText, Panel } from '@/components/ui';
import { useAppColors } from '@/src/theme';
import { useAppState } from '@/src/state';

const DOWNLOAD_SCRIPT = `
(function () {
  function isDownloadLink(url, anchor) {
    if (anchor && anchor.hasAttribute('download')) return true;
    try {
      var path = new URL(url, location.href).pathname.toLowerCase();
      return /\.(zip|7z|rar|r[0-9]{2}|ipa|apk|xapk|obb|pdf|epub|dmg|exe|msi|pkg|deb|iso|tar|gz|bz2|xz|zst|mp3|mp4|m4v|mov|webm|3gp|wav|flac|ogg|jpg|jpeg|png|gif|webp|bin|dat|pak|obb|torrent|txt|csv|json|doc|docx|xls|xlsx|ppt|pptx)$/.test(path);
    } catch (_) { return false; }
  }
  document.addEventListener('click', function (event) {
    var anchor = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!anchor) return;
    var url = anchor.href;
    if (isDownloadLink(url, anchor)) {
      event.preventDefault(); event.stopPropagation();
      window.ReactNativeWebView.postMessage(JSON.stringify({type:'download', url:url}));
    }
  }, true);
  window.addEventListener('message', function () {});
})(); true;
`;

export default function BrowserScreen() {
  const colors = useAppColors();
  const { startDownload } = useAppState();
  const web = useRef<WebView>(null);
  const [address, setAddress] = useState('https://example.com');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [currentUrl, setCurrentUrl] = useState('https://example.com');
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState('KGP Browser');

  const navigate = useCallback(() => {
    let target = address.trim();
    if (!target) return;
    if (!/^https?:\/\//i.test(target)) target = `https://${target}`;
    try { new URL(target); setAddress(target); setCurrentUrl(target); }
    catch { Alert.alert('Invalid address', 'Enter a valid website address.'); }
  }, [address]);

  const beginDownload = useCallback(async (url: string) => {
    const candidate = url.trim();
    if (!candidate) {
      Alert.alert('Missing link', 'Paste a direct file URL first.');
      return;
    }
    try {
      await startDownload(candidate);
      setDownloadUrl('');
      Alert.alert('Download added', 'The link was sent to the KGP Download Manager. If this is a hosting page rather than a direct file URL, open it in the browser and use its normal download button.');
    } catch (error) {
      Alert.alert('Download could not start', error instanceof Error ? error.message : 'Check the link and try again.');
    }
  }, [startDownload]);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background, paddingHorizontal: 10, paddingTop: 6, paddingBottom: 82, gap: 8 }}>
      <View style={styles.toolbar}>
        <Pressable onPress={() => web.current?.goBack()} style={styles.icon}><Ionicons name="chevron-back" size={21} color={colors.foreground} /></Pressable>
        <Pressable onPress={() => web.current?.goForward()} style={styles.icon}><Ionicons name="chevron-forward" size={21} color={colors.foreground} /></Pressable>
        <Pressable onPress={() => web.current?.reload()} style={styles.icon}><Ionicons name="refresh" size={19} color={colors.foreground} /></Pressable>
        <TextInput value={address} onChangeText={setAddress} onSubmitEditing={navigate} autoCapitalize="none" autoCorrect={false} keyboardType="url" returnKeyType="go" style={[styles.address, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]} placeholder="Enter website URL" placeholderTextColor={colors.mutedForeground} />
        <Pressable onPress={navigate} style={[styles.go, { backgroundColor: colors.primary }]}><Ionicons name="arrow-forward" size={18} color="#111" /></Pressable>
      </View>
      <View style={styles.downloadRow}>
        <Ionicons name="link-outline" size={17} color={colors.mutedForeground} />
        <TextInput
          value={downloadUrl}
          onChangeText={setDownloadUrl}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          returnKeyType="go"
          onSubmitEditing={() => void beginDownload(downloadUrl)}
          placeholder="Paste direct download URL (HTTPS)"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.downloadInput, { color: colors.foreground }]}
        />
        <Pressable onPress={() => void beginDownload(downloadUrl)} style={[styles.downloadButton, { backgroundColor: colors.primary }]} accessibilityRole="button" accessibilityLabel="Add download link">
          <Ionicons name="download-outline" size={18} color="#111" />
        </Pressable>
      </View>
      <View style={{ flex: 1, minHeight: 300, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: colors.border }}>
        <WebView
          ref={web}
          source={{ uri: currentUrl }}
          injectedJavaScript={DOWNLOAD_SCRIPT}
          onMessage={(event) => {
            try { const message = JSON.parse(event.nativeEvent.data); if (message.type === 'download' && typeof message.url === 'string') void beginDownload(message.url); } catch {}
          }}
          onShouldStartLoadWithRequest={(request) => {
            const url = request.url;
            if (/\.(zip|7z|rar|r[0-9]{2}|ipa|apk|xapk|obb|pdf|epub|dmg|exe|msi|pkg|deb|iso|tar|gz|bz2|xz|zst|mp3|mp4|m4v|mov|webm|3gp|wav|flac|ogg|jpg|jpeg|png|gif|webp|bin|dat|pak|torrent|txt|csv|json|doc|docx|xls|xlsx|ppt|pptx)(?:[?#].*)?$/i.test(url)) {
              void beginDownload(url);
              return false;
            }
            return true;
          }}
          onFileDownload={({ nativeEvent }) => { if (nativeEvent.downloadUrl) void beginDownload(nativeEvent.downloadUrl); }}
          onLoadStart={() => setLoading(true)}
          onLoadEnd={(event) => { setLoading(false); setAddress(event.nativeEvent.url); setTitle(event.nativeEvent.title || 'KGP Browser'); }}
          onError={({ nativeEvent }) => Alert.alert('Website error', nativeEvent.description)}
          javaScriptEnabled
          domStorageEnabled
          allowsBackForwardNavigationGestures
          setSupportMultipleWindows={false}
          style={{ flex: 1, backgroundColor: colors.background }}
        />
      </View>
      <Panel style={styles.footer}>
        <AppText numberOfLines={1} style={{ color: colors.foreground, fontSize: 11, flex: 1 }}>{title}</AppText>
        <AppText style={{ color: colors.mutedForeground, fontSize: 10 }}>{loading ? 'Loading…' : 'KGP Download Manager enabled'}</AppText>
      </Panel>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  toolbar: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  icon: { width: 32, height: 38, alignItems: 'center', justifyContent: 'center' },
  address: { flex: 1, height: 38, borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, fontSize: 12 },
  downloadRow: { minHeight: 44, flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 10, borderRadius: 10, borderWidth: 1, borderColor: '#B88A35' },
  downloadInput: { flex: 1, minWidth: 0, height: 42, fontSize: 12 },
  downloadButton: { width: 36, height: 36, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  go: { width: 38, height: 38, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  footer: { paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 10 },
});
