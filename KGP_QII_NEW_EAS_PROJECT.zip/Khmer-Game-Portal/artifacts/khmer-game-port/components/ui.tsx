import React, { type ReactNode } from 'react';
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/src/state';
import { useAppColors } from '@/src/theme';

export function AppText({
  children,
  style,
  weight = 'regular',
  ...props
}: React.ComponentProps<typeof Text> & { weight?: 'regular' | 'medium' | 'bold' }) {
  const { data } = useAppState();
  const fontFamily =
    data.preferences.language === 'km'
      ? undefined
      : weight === 'bold'
        ? 'Inter_700Bold'
        : weight === 'medium'
          ? 'Inter_500Medium'
          : 'Inter_400Regular';
  return (
    <Text {...props} style={[{ fontFamily }, style]}>
      {children}
    </Text>
  );
}

export function Screen({ children, contentStyle }: { children: ReactNode; contentStyle?: ViewStyle }) {
  const colors = useAppColors();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={[
          styles.screenContent,
          styles.centeredContent,
          {
            paddingTop: Platform.OS === 'web' ? 67 : Math.max(insets.top, 12),
            paddingBottom: Platform.OS === 'web' ? 118 : 112 + insets.bottom,
          },
          contentStyle,
        ]}
      >
        {children}
      </ScrollView>
    </View>
  );
}

export function Panel({
  children,
  style,
}: {
  children: ReactNode;
  style?: ViewStyle;
}) {
  const colors = useAppColors();
  return (
    <View
      style={[
        styles.panel,
        { backgroundColor: colors.card, borderColor: colors.border },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionTitle({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.sectionTitleRow}>
      <AppText weight="bold" style={[styles.sectionTitle, { color: colors.foreground }]}>
        {title}
      </AppText>
      {action && onAction ? (
        <Pressable onPress={onAction} hitSlop={8} accessibilityRole="button">
          <AppText weight="medium" style={{ color: colors.primary, fontSize: 13 }}>
            {action}
          </AppText>
        </Pressable>
      ) : null}
    </View>
  );
}

export function ActionButton({
  label,
  onPress,
  icon,
  secondary = false,
  disabled = false,
  testID,
  loading = false,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  secondary?: boolean;
  disabled?: boolean;
  testID?: string;
  loading?: boolean;
}) {
  const colors = useAppColors();
  const { data } = useAppState();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={() => {
        if (data.preferences.hapticsEnabled) void Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.actionButton,
        {
          backgroundColor: secondary ? colors.secondary : colors.primary,
          borderColor: secondary ? colors.border : colors.primary,
          opacity: disabled ? 0.45 : pressed ? 0.78 : 1,
          transform: [{ scale: pressed ? 0.985 : 1 }],
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={secondary ? colors.primary : colors.accentForeground} />
      ) : icon ? (
        <Ionicons name={icon} size={17} color={secondary ? colors.primary : colors.accentForeground} />
      ) : null}
      <AppText
        weight="bold"
        style={{
          color: secondary ? colors.foreground : colors.accentForeground,
          fontSize: 13,
        }}
      >
        {label}
      </AppText>
    </Pressable>
  );
}

export function IconButton({
  icon,
  onPress,
  label,
  color,
  testID,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  label: string;
  color?: string;
  testID?: string;
}) {
  const colors = useAppColors();
  const { data } = useAppState();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={10}
      onPress={() => {
        if (data.preferences.hapticsEnabled) void Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.65 : 1 }]}
    >
      <Ionicons name={icon} size={20} color={color ?? colors.foreground} />
    </Pressable>
  );
}

export function Tag({
  label,
  tone = 'neutral',
}: {
  label: string;
  tone?: 'neutral' | 'accent' | 'danger' | 'success';
}) {
  const colors = useAppColors();
  const toneColor =
    tone === 'accent'
      ? colors.primary
      : tone === 'danger'
        ? colors.destructive
        : tone === 'success'
          ? colors.success
          : colors.mutedForeground;
  return (
    <View
      style={[
        styles.tag,
        { borderColor: `${toneColor}66`, backgroundColor: `${toneColor}18` },
      ]}
    >
      <AppText weight="medium" style={{ color: toneColor, fontSize: 10, letterSpacing: 0.4 }}>
        {label.toUpperCase()}
      </AppText>
    </View>
  );
}

export function SearchField({
  value,
  onChangeText,
  placeholder,
  testID,
}: Pick<TextInputProps, 'value' | 'onChangeText' | 'placeholder' | 'testID'>) {
  const colors = useAppColors();
  return (
    <View style={[styles.searchField, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Ionicons name="search-outline" size={18} color={colors.mutedForeground} />
      <TextInput
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        selectionColor={colors.primary}
        style={[styles.searchInput, { color: colors.foreground }]}
        autoCapitalize="none"
        returnKeyType="search"
      />
    </View>
  );
}

export function FormField({
  label,
  value,
  onChangeText,
  placeholder,
  multiline = false,
  keyboardType,
  autoCapitalize,
  secureTextEntry,
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  multiline?: boolean;
  keyboardType?: TextInputProps['keyboardType'];
  autoCapitalize?: TextInputProps['autoCapitalize'];
  secureTextEntry?: boolean;
}) {
  const colors = useAppColors();
  return (
    <View style={{ gap: 8 }}>
      <AppText weight="medium" style={{ color: colors.mutedForeground, fontSize: 12 }}>
        {label}
      </AppText>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        selectionColor={colors.primary}
        multiline={multiline}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize}
        secureTextEntry={secureTextEntry}
        style={[
          styles.formInput,
          {
            color: colors.foreground,
            backgroundColor: colors.background,
            borderColor: colors.border,
            minHeight: multiline ? 90 : 48,
            textAlignVertical: multiline ? 'top' : 'center',
          },
        ]}
      />
    </View>
  );
}

export function Sheet({
  visible,
  title,
  onClose,
  children,
}: {
  visible: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const colors = useAppColors();
  const { height } = useWindowDimensions();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior="padding"
        keyboardVerticalOffset={0}
        style={styles.modalBackdrop}
      >
        <Pressable
          style={[StyleSheet.absoluteFill, { backgroundColor: colors.overlay }]}
          onPress={onClose}
          accessibilityLabel="Close dialog"
        />
        <View
          style={[
            styles.sheet,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              maxHeight: height * 0.88,
            },
          ]}
        >
          <View style={[styles.sheetHandle, { backgroundColor: colors.handle }]} />
          <View style={styles.sheetHeader}>
            <AppText weight="bold" style={{ color: colors.foreground, fontSize: 18 }}>
              {title}
            </AppText>
            <IconButton icon="close" label="Close" onPress={onClose} />
          </View>
          <KeyboardAwareScrollViewCompat
            keyboardShouldPersistTaps="handled"
            bottomOffset={64}
            contentContainerStyle={{ gap: 16, paddingBottom: 28 }}
          >
            {children}
          </KeyboardAwareScrollViewCompat>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export function EmptyState({
  icon,
  title,
  detail,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  detail: string;
}) {
  const colors = useAppColors();
  return (
    <View style={styles.empty}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Ionicons name={icon} size={23} color={colors.primary} />
      </View>
      <AppText weight="bold" style={{ color: colors.foreground, fontSize: 15, textAlign: 'center' }}>
        {title}
      </AppText>
      <AppText style={{ color: colors.mutedForeground, fontSize: 12, textAlign: 'center', lineHeight: 19 }}>
        {detail}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  screenContent: { paddingHorizontal: 20, gap: 20 },
  centeredContent: { width: '100%', maxWidth: 760, alignSelf: 'center' },
  panel: {
    borderWidth: 1,
    borderRadius: 20,
    padding: 16,
    gap: 12,
  },
  sectionTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 12,
  },
  sectionTitle: { fontSize: 16, letterSpacing: -0.3 },
  actionButton: {
    minHeight: 46,
    borderRadius: 14,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
  },
  iconButton: {
    minWidth: 32,
    minHeight: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tag: {
    borderWidth: 1,
    borderRadius: 100,
    paddingHorizontal: 9,
    paddingVertical: 5,
    alignSelf: 'flex-start',
  },
  searchField: {
    height: 48,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  searchInput: { flex: 1, fontSize: 14, paddingVertical: 0 },
  formInput: {
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
  },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'transparent' },
  sheet: {
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
    borderWidth: 1,
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  sheetHandle: {
    width: 38,
    height: 4,
    borderRadius: 3,
    alignSelf: 'center',
    marginBottom: 14,
  },
  sheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  empty: { alignItems: 'center', paddingVertical: 28, paddingHorizontal: 16, gap: 9 },
  emptyIcon: {
    width: 50,
    height: 50,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
});
