---
name: KHMER GAME PORT product boundaries
description: Truthful iOS capability and compatibility limits for this Khmer-first game companion.
---

The product is branded KHMER GAME PORT by Qii Qii. Do not present the Windows/PC version of GTA V as playable natively on iOS, and do not claim the app can install arbitrary IPA files.

Never claim a downloadable IPA exists until the actual IPA file has been produced and verified. A type check, prebuild, JavaScript export, or App Store submission is not an IPA.

**Why:** The product brief specifies these platform limits and requires evidence before claiming an IPA build or install capability.

**How to apply:** Keep engine-dependent features unavailable or clearly labeled until a compatible, authorized iOS runtime and real native bridge are implemented. Report build status based on the artifact actually produced.
