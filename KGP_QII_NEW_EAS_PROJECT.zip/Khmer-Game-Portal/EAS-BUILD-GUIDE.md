# KGP QII — EAS Build

The Expo app and its EAS configuration are located at:

- App directory: `artifacts/khmer-game-port/`
- EAS profiles: `artifacts/khmer-game-port/eas.json` (`development`, `preview`, `production`)
- Workspace dependency lockfile: repository-root `pnpm-lock.yaml`

## Build from a local checkout

```sh
pnpm install --frozen-lockfile
cd artifacts/khmer-game-port
npx eas-cli build --platform ios --profile preview
```

Use `--profile development` or `--profile production` to select another profile.

## Build with GitHub Actions

1. In the GitHub repository, open **Settings → Secrets and variables → Actions**.
2. Add a repository secret named `EXPO_TOKEN` containing an Expo access token.
3. Open **Actions → EAS Build → Run workflow** and select a profile.

The workflow installs dependencies from the existing root `pnpm-lock.yaml` with `--frozen-lockfile`, then runs EAS from the Expo app directory. It does not delete or replace project files.
