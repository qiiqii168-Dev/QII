#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/../upstream" && pwd)"
GAME_DIR="${1:-}"
if [[ -z "$GAME_DIR" || ! -d "$GAME_DIR" ]]; then
  echo "Usage: $0 /absolute/path/to/game-folder" >&2; exit 2
fi
if [[ "$(uname -s)" != "Darwin" || "$(uname -m)" != "arm64" ]]; then
  echo "ERROR: Native build requires Apple Silicon macOS + Xcode." >&2; exit 3
fi
command -v xcodebuild >/dev/null || { echo "ERROR: Xcode command line tools missing" >&2; exit 4; }
command -v xcodegen >/dev/null || { echo "Install xcodegen: brew install xcodegen" >&2; exit 5; }
python3 "$(dirname "$0")/audit_engine_inputs.py" "$GAME_DIR"
cd "$HERE"
./build_ipa.sh --mirror "$GAME_DIR"
echo "Upstream standalone IPA build finished. This does NOT yet link the engine into KGP QII."
