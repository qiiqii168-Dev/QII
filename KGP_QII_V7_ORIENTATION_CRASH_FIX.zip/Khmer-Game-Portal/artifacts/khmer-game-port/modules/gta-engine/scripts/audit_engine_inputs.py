#!/usr/bin/env python3
from pathlib import Path
import sys
root = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv)>1 else None
if not root or not root.is_dir():
    raise SystemExit("Usage: python3 audit_engine_inputs.py /path/to/game-folder")
checks = {
    "data directory": root / "data",
    "build directory": root / "b" / "8b0b5899ed",
    "game.wasm": root / "b" / "8b0b5899ed" / "game.wasm",
}
failed=False
for label,path in checks.items():
    ok=path.exists()
    print(("OK   " if ok else "MISS ")+f"{label}: {path}")
    failed |= not ok
if failed:
    raise SystemExit("Game folder does not match required 5★ Port layout build 8b0b5899ed")
print("Game folder layout looks correct. Upstream prepare.py still verifies hashes and assets.")
