# GTA Engine upstream source staging

## What is included

The upstream `gta5-ios-port` source archive is preserved under `upstream/` for review and future native integration. Its upstream `LICENSE` is included. Git metadata was excluded to avoid copying repository history; project source, scripts, docs, assets, and build configuration files were retained.

## Important build status

This is **source staging, not a completed engine integration**. The existing Expo module bridge remains unchanged and still reports that the engine is not linked. The upstream project is a standalone XcodeGen iOS application, not an Expo module or CocoaPods-ready engine framework. It expects an Apple Silicon Mac with Xcode and xcodegen, and its build preparation step requires the user's own legally obtained game files.

The upstream Xcode project references generated build inputs such as `Generated/`, `Tools/wabt-1.0.42/`, `Tools/simde/`, `Tools/opus-1.5.2/`, `Tools/opus-lib/`, `Tools/blink-lib/`, and optionally `GeneratedResources/`. These are not present in either supplied ZIP. The upstream `app/Scripts/prepare.py` is the intended preparation entry point; do not create empty placeholder folders or claim these generated outputs exist.

## Safe next integration steps

1. Review `upstream/app/Scripts/prepare.py` and its helper scripts to map reproducible generated inputs.
2. On a supported Mac build host, obtain/build the documented toolchain and generate the engine inputs using the user's own game files.
3. Design a proper native engine target/framework and connect its lifecycle/rendering/input APIs to `GTAEngineModule.swift`.
4. Keep the Expo app target and EAS workflow separate from the standalone upstream target until the native integration is validated.
5. Run Xcode build and device tests before changing the bridge status to gameplay-ready.

## Source integrity

The original KGP project files and existing `GTAEngineModule.swift`, podspec, package files, and EAS configuration were retained unchanged in this staging pass. Only this upstream source subtree and this status document were added.


## V7 Native extraction audit

Inspected upstream v1.5.2 `app/project.yml`: it is a standalone `PlayGTA5Native` application target, not a reusable framework. `EngineHost`/`MetalGraphicsHost` depend on generated WASM C, WABT runtime, shaders/resources, app services and vendor libraries. Blindly adding upstream `Source/**/*` to the podspec would be incorrect. See `integration/NATIVE_ENGINE_EXTRACTION_AUDIT_KM.md` and `integration/KGP_ENGINE_LINK_BLOCKERS_KM.md`. Added an Apple-Silicon build wrapper and game-folder layout audit. No engine binary or KGP link is claimed.
