# បញ្ជីការងារ Native Engine → KGP QII

1. Run upstream `prepare.py` លើ Mac Apple Silicon ជាមួយ game build `8b0b5899ed` ដើម្បីបង្កើត `Generated/`, WABT runtime, generated shaders/resources និង native vendor libs។
2. បង្កើត target `GTAEngineCore` (static library ឬ XCFramework) ពី `Source/`, generated C, WABT runtime និង vendor libs។ ត្រូវបំបែក UI/App layer ចេញពី Engine layer។
3. បង្កើត public C/ObjC interface សម្រាប់ initialize, mount game files, start/stop, resize drawable, input events និង lifecycle។
4. Refactor Metal host ឱ្យទទួល `MTKView`/drawable ពី KGP host view; កុំប្រើ AppDelegate/SceneDelegate របស់ upstream app។
5. បម្លែង upstream settings, game-folder manager, logging, audio session និង controller routing ទៅ dependency-injected interfaces។
6. បង្កើត `GTAEngine.xcframework` សម្រាប់ iphoneos arm64 និង link ក្នុង `GTAEngine.podspec`; embed resources និង shader metallib តាម bundle។
7. បន្ថែម Expo `GTAEngineView` និង native module lifecycle; កុំអនុញ្ញាត launch រហូត `engineLinked && gameFilesReady`។
8. Build IPA, symbolicate crash, install និង test លើ iPhone 14 Pro Max។

ចំណុច 2–6 ជាការងារ refactor ពិតប្រាកដ មិនអាចជំនួសដោយការបន្ថែម path ទៅ podspec ឬចម្លង source files ទេ។
