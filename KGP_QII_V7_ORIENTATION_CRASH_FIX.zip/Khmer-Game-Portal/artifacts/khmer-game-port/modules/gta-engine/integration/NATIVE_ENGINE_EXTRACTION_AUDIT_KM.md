# Native GTA V Engine — Integration Audit (KGP QII V7)

## លទ្ធផលពិនិត្យ Source v1.5.2

5★ Port មិនផ្ដល់ Engine ជា standalone framework ឬ XCFramework ទេ។ វាបង្កើតជា iOS application target `PlayGTA5Native` តាម `app/project.yml`។ Target នោះប្រមូល `App/`, `Source/`, `Generated/`, `Resources/`, `GeneratedResources/` និង runtime files ពី WABT ព្រមទាំង link `libopus`, `libblink`, `libarchive`។

`EngineHost` និង `MetalGraphicsHost` មិនមែនជា API សាធារណៈដែលអាចដាក់ក្នុង CocoaPods ភ្លាមៗបានទេ៖ វាអាស្រ័យលើ NativeRuntime, generated WASM C files, shader assets, app lifecycle, settings, game-file manager និង native vendor libraries។ ការចម្លងតែ `Source/` ទៅ `GTAEngine.podspec` នឹងបង្កើត compile/link errors ហើយមិនបង្កើតហ្គេមដែលដំណើរការបានទេ។

## អ្វីដែលត្រូវបានបន្ថែម

- `scripts/prepare_and_build_upstream.sh`: ប្រើ upstream build pipeline ដើម ដោយទាមទារ Apple Silicon macOS, Xcode, XcodeGen និង game folder ត្រឹមត្រូវ។
- `scripts/audit_engine_inputs.py`: ពិនិត្យ `data/`, `b/8b0b5899ed/`, `game.wasm` និង build-generated folders មុនចាប់ផ្ដើម។
- `KGP_ENGINE_LINK_BLOCKERS_KM.md`: បញ្ជីជំហានចាំបាច់មុនអាចបំបែក app target ទៅជា framework និងបញ្ចូល KGP។

## ស្ថានភាពមិនត្រូវច្រឡំ

- Upstream source: bundled.
- Generated engine C / wasm runtime: មិនបានបង្កើតក្នុង ZIP។
- Metal shaders: មិនបាន compile ក្នុង ZIP។
- Native iOS framework: មិនទាន់មាន។
- KGP CocoaPods link: មិនទាន់ធ្វើ។
- Playable GTA V in KGP QII: មិនទាន់មាន/មិនទាន់សាកល្បង។

មូលហេតុ៖ environment បច្ចុប្បន្នសម្រាប់កែ ZIP មិនមែន macOS/Xcode ហើយ game data 21GB របស់អ្នកមិនមានក្នុង working files នេះ។ មិនអាចបង្កើត binary iOS ត្រឹមត្រូវដោយក្លែងធ្វើលើ Linux បានទេ។
