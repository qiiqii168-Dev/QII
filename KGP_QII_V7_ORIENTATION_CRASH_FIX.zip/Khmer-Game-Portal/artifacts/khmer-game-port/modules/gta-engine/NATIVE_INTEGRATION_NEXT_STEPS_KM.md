# KGP QII × Five Star Port — Native Integration Status

## What is present

- The Five Star Port v1.5.2 source is bundled in `upstream/`.
- `GTAEngineModule.swift` is an Expo bridge placeholder and reports the engine as not linked.
- `GTAEngine.podspec` currently compiles only the bridge files. It does **not** compile or link the upstream engine/Metal renderer.
- `upstream/build_ipa.sh` is the upstream project's supported build entry point.

## Build the real upstream native game first

On an Apple Silicon Mac with Xcode and `xcodegen` installed:

```sh
brew install xcodegen
./modules/gta-engine/build-native-gta-ipa.sh "/absolute/path/to/your/game-folder"
```

The game folder must be the matching Web build `8b0b5899ed` and contain `data/` and `b/8b0b5899ed/`. The script invokes the upstream `check_game_files.py`, `prepare.py`, and Xcode build through `build_ipa.sh`. The resulting standalone IPA is copied to `modules/gta-engine/build-output/`.

## Why this is not yet embedded in KGP QII

The upstream repository is a complete standalone iOS application, not a reusable XCFramework or CocoaPods library. Its app lifecycle, UIKit controllers, Metal renderer, game runtime, resources, entitlements, and generated WASM-to-C output are wired to its own Xcode target. Simply adding its `.swift`, `.mm`, or `.c` files to `GTAEngine.podspec` would produce duplicate app symbols, missing generated inputs, or lifecycle/resource conflicts. The bridge must be refactored into a library boundary before KGP QII can host it in-process.

## Required next engineering phase

1. Build and validate the upstream standalone IPA on a supported Mac using the user's own matching game data.
2. Identify the minimal engine lifecycle and renderer API that can be separated from the upstream app delegate and view controllers.
3. Refactor those components into a static library/XCFramework with explicit headers, resources, Metal shader bundle, and required entitlements.
4. Add the resulting framework and resource bundle to the Expo iOS target and implement the Expo module's real start/stop/status methods.
5. Run an Xcode build, install on the iPhone, and verify gameplay and crash logs before reporting success.

## Important truth-in-status rule

Until steps 1–5 are completed and tested, `engineLinked`, `metalRendererLinked`, `storyModeAvailable`, and `sandboxAvailable` must remain `false`. This project ZIP is source preparation plus a repeatable upstream build helper; it is **not** a playable KGP QII GTA IPA.
