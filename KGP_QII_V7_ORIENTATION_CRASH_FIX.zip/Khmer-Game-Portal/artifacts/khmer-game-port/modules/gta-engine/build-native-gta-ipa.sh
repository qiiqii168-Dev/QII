#!/usr/bin/env bash
# Build the bundled Five Star Port as a standalone native iOS IPA.
# This intentionally does NOT claim to link it into the Expo/KGP QII app.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
UPSTREAM="$HERE/upstream"
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: Native GTA build requires macOS on Apple Silicon." >&2
  exit 2
fi
if [[ "$(uname -m)" != "arm64" ]]; then
  echo "ERROR: Use an Apple Silicon Mac (arm64), not Intel or Rosetta." >&2
  exit 2
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERROR: Xcode command-line tools are required." >&2
  exit 2
fi
if ! command -v xcodegen >/dev/null 2>&1; then
  echo "ERROR: Install xcodegen first: brew install xcodegen" >&2
  exit 2
fi
if [[ $# -lt 1 ]]; then
  echo "Usage: $0 /absolute/path/to/game-folder [--free] [--lite]" >&2
  echo "The folder must contain data/ and b/ (Web build 8b0b5899ed)." >&2
  exit 2
fi
GAME_DIR="$(cd "$1" && pwd)"
shift
if [[ ! -d "$GAME_DIR/data" || ! -d "$GAME_DIR/b/8b0b5899ed" ]]; then
  echo "ERROR: Expected data/ and b/8b0b5899ed/ in: $GAME_DIR" >&2
  exit 2
fi
cd "$UPSTREAM"
./build_ipa.sh --mirror "$GAME_DIR" "$@"
IPA="$UPSTREAM/GTA5Port.ipa"
[[ "${*: -1}" == "--lite" ]] && IPA="$UPSTREAM/GTA5Port-Lite.ipa"
if [[ ! -f "$IPA" ]]; then
  echo "ERROR: Upstream build finished without producing the expected IPA." >&2
  exit 3
fi
OUT="$HERE/build-output"
mkdir -p "$OUT"
cp -f "$IPA" "$OUT/"
echo "Standalone native GTA IPA created: $OUT/$(basename "$IPA")"
echo "This IPA is the upstream Five Star Port app, not yet embedded into KGP QII."
