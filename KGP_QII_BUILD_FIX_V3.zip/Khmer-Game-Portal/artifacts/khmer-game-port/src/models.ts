export type Compatibility = 'unknown' | 'partial' | 'incompatible';

export interface GameProfile {
  id: string;
  name: string;
  description: string;
  version: string;
  compatibility: Compatibility;
  favorite: boolean;
  createdAt: number;
  lastPlayedAt?: number;
}

export interface VaultFile {
  id: string;
  name: string;
  uri: string;
  sizeBytes: number;
  extension: string;
  importedAt: number;
  source: 'import' | 'download' | 'extract';
}

export type DownloadStatus =
  | 'queued'
  | 'downloading'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface DownloadRecord {
  id: string;
  url: string;
  fileName: string;
  fileUri: string;
  status: DownloadStatus;
  transferredBytes: number;
  totalBytes: number;
  createdAt: number;
  error?: string;
  resumeData?: string;
  speedBytesPerSecond?: number;
  etaSeconds?: number;
  rangeSupport?: 'yes' | 'no' | 'unknown';
  serverETag?: string;
  serverLastModified?: string;
  contentType?: string;
}

export interface ModRecord {
  id: string;
  name: string;
  gameName: string;
  notes: string;
  enabled: boolean;
  createdAt: number;
  category?: ModCategory;
  fileId?: string;
}

export type ModCategory = 'Gameplay' | 'Graphics' | 'Audio' | 'UI' | 'Other';

export interface ControlPreset {
  id: string;
  name: string;
  kind: 'Driving' | 'Walking' | 'Shooting' | 'Custom';
  sensitivity: number;
  movementSensitivity?: number;
  cameraSensitivity?: number;
  vehicleSensitivity?: number;
  joystickSide?: 'left' | 'right';
  opacity: number;
  buttonScale: number;
  active: boolean;
  builtIn: boolean;
}

export interface AudioTrack {
  id: string;
  name: string;
  uri: string;
  addedAt: number;
}

export interface ActivityRecord {
  id: string;
  label: string;
  kind: 'game' | 'file' | 'download' | 'mod' | 'settings' | 'backup' | 'system';
  createdAt: number;
}

export interface Preferences {
  introEnabled: boolean;
  introSeen: boolean;
  hapticsEnabled: boolean;
  language: 'en' | 'km';
  accent: 'gold' | 'ember' | 'jade';
  logoColor: string;
  playerName: string;
  graphicsPreset?: 'performance' | 'balanced' | 'quality';
  resolutionTarget?: 'native' | '720p' | '1080p';
  frameRateTarget?: 30 | 60 | 120;
}

export interface AppData {
  version: 1;
  games: GameProfile[];
  files: VaultFile[];
  downloads: DownloadRecord[];
  mods: ModRecord[];
  controls: ControlPreset[];
  audioTracks: AudioTrack[];
  activity: ActivityRecord[];
  preferences: Preferences;
}

export const makeId = (prefix: string) =>
  `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export const defaultControls = (): ControlPreset[] => [
  {
    id: 'preset-driving',
    name: 'Driving',
    kind: 'Driving',
    sensitivity: 65,
    movementSensitivity: 65,
    cameraSensitivity: 60,
    vehicleSensitivity: 70,
    joystickSide: 'left',
    opacity: 75,
    buttonScale: 100,
    active: true,
    builtIn: true,
  },
  {
    id: 'preset-walking',
    name: 'Walking',
    kind: 'Walking',
    sensitivity: 55,
    movementSensitivity: 60,
    cameraSensitivity: 55,
    vehicleSensitivity: 50,
    joystickSide: 'left',
    opacity: 80,
    buttonScale: 100,
    active: false,
    builtIn: true,
  },
  {
    id: 'preset-shooting',
    name: 'Shooting',
    kind: 'Shooting',
    sensitivity: 72,
    movementSensitivity: 55,
    cameraSensitivity: 75,
    vehicleSensitivity: 50,
    joystickSide: 'left',
    opacity: 70,
    buttonScale: 100,
    active: false,
    builtIn: true,
  },
];

export const initialAppData = (): AppData => ({
  version: 1,
  games: [],
  files: [],
  downloads: [],
  mods: [],
  controls: defaultControls(),
  audioTracks: [],
  activity: [],
  preferences: {
    introEnabled: true,
    introSeen: false,
    hapticsEnabled: true,
    language: 'km',
    accent: 'gold',
    logoColor: '#8B5CF6',
    playerName: '',
  },
});
