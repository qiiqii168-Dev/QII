import React from 'react';
import { View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export const LOGO_COLOR_OPTIONS = [
  { key: '#8B5CF6', name: 'Violet' }, { key: '#3B82F6', name: 'Ocean' },
  { key: '#14B8A6', name: 'Teal' }, { key: '#22C55E', name: 'Emerald' },
  { key: '#F59E0B', name: 'Amber' }, { key: '#F43F5E', name: 'Rose' },
  { key: '#EC4899', name: 'Pink' }, { key: '#E5E7EB', name: 'Silver' },
] as const;

export function BrandLogo({ color = '#8B5CF6', size = 58 }: { color?: string; size?: number }) {
  return (
    <LinearGradient colors={[color, '#171426', '#090A12']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      style={{ width: size, height: size, borderRadius: size * 0.27, alignItems: 'center', justifyContent: 'center',
        borderWidth: 1.5, borderColor: `${color}CC`, shadowColor: color, shadowOpacity: 0.28,
        shadowRadius: size * 0.16, shadowOffset: { width: 0, height: 3 }, elevation: 5 }}>
      <Ionicons name="game-controller" size={size * 0.42} color="#FFFFFF" />
      <View style={{ marginTop: -size * 0.015, paddingHorizontal: size * 0.12, paddingVertical: 1,
        borderRadius: 5, backgroundColor: color }}>
        <Ionicons name="sparkles" size={size * 0.13} color="#111018" />
      </View>
    </LinearGradient>
  );
}
