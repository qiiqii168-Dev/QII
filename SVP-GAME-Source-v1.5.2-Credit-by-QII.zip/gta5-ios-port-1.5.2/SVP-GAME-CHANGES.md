# SVP GAME — Credit by QII

## Changes in this package
- Set the iOS Home Screen display name to `SVP GAME`.
- Set the bundle display/name metadata to `SVP GAME`.
- Updated in-app references and Files-folder guidance from `GTA V Port` to `SVP GAME`.
- Kept the original target/scheme name, bundle identifier, engine code, assets, entitlements, and game functionality unchanged to minimize build/runtime risk.
- Added `CREDITS-QII.txt`.

## Build status
This package is source only. It has not been built or run on an iPhone in this environment. Build with Xcode on macOS using the project's documented scripts.
