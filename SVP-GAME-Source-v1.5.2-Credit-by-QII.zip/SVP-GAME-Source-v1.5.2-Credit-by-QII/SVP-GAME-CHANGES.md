# SVP GAME — Credit by QII

- Source base: GTA V iOS Port v1.5.2 (user-provided archive).
- App display name changed to **SVP GAME**.
- Credit recorded as **QII**.
- Original source files, assets, project target/module identifiers, bundle identifier, and build configuration retained.
- This is a branded source project, not a compiled IPA. Build and runtime validation have not been performed.
